document.addEventListener("DOMContentLoaded", () => {
    // Progress circle animations
    const numbers = document.querySelectorAll('.progresss .percentage p');
    const circles = document.querySelectorAll('.progresss svg circle');

    numbers.forEach((number, index) => {
        let target = parseFloat(circles[index].getAttribute('data-num')) || 100;
        let count = 0;
        let interval = setInterval(() => {
            if (count >= target) {
                clearInterval(interval);
            } else {
                count++;
                number.innerHTML = `+${count}%`;
                circles[index].style.strokeDashoffset = Math.floor(200 - (200 * count) / 100);
            }
        }, 20);
    });

    // Total progress calculation
    let attendance = parseFloat(document.getElementById("attendance").innerText);
    let cgpa = parseFloat(document.getElementById("cgpa").innerText) * 25;
    let skills = parseFloat(document.getElementById("skills").innerText) * 10;
    let totalProgress = Math.round((attendance + cgpa + skills) / 3);
    
    let totalProgressEl = document.getElementById("total-progress");
    let circle = document.getElementById("total-progress-circle");
    let count = 0;

    let interval = setInterval(() => {
        if (count >= totalProgress) {
            clearInterval(interval);
        } else {
            count++;
            totalProgressEl.innerText = count + "%";
            circle.style.strokeDashoffset = Math.floor(280 - (280 * count) / 100);
        }
    }, 20);

    // Sidebar toggle
    const sideMenu = document.querySelector('aside');
    const menuBtn = document.getElementById('menu-btn');
    const closeBtn = document.getElementById('close-btn');

    menuBtn.addEventListener('click', () => {
        sideMenu.style.display = 'block';
    });

    closeBtn.addEventListener('click', () => {
        sideMenu.style.display = 'none';
    });

    // Reminders functionality
    const addReminderBtn = document.querySelector('.add-reminder-btn');
    const addReminderForm = document.querySelector('.add-reminder-form');
    const saveReminderBtn = document.querySelector('.save-reminder');
    const cancelReminderBtn = document.querySelector('.cancel-reminder');
    const remindersList = document.querySelector('.reminders-list');

    // Show add reminder form
    addReminderBtn.addEventListener('click', () => {
        addReminderForm.style.display = 'block';
        addReminderBtn.style.display = 'none';
    });

    // Cancel adding reminder
    cancelReminderBtn.addEventListener('click', () => {
        addReminderForm.style.display = 'none';
        addReminderBtn.style.display = 'flex';
        document.getElementById('reminder-title').value = '';
        document.getElementById('reminder-date').value = '';
    });

    // Save new reminder
    saveReminderBtn.addEventListener('click', () => {
        const title = document.getElementById('reminder-title').value;
        const dateTime = document.getElementById('reminder-date').value;
        
        if (title && dateTime) {
            const date = new Date(dateTime);
            const formattedDate = date.toLocaleDateString('en-US', { 
                month: 'short', 
                day: 'numeric', 
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            const colors = ['success', 'primary', 'warning', 'danger'];
            const randomColor = colors[Math.floor(Math.random() * colors.length)];
            
            const newReminder = document.createElement('div');
            newReminder.className = 'notification bg-white p-3 rounded-3 shadow-sm d-flex align-items-center gap-3 mb-3';
            newReminder.innerHTML = `
                <div class="icon p-2 bg-${randomColor} rounded-2 d-flex align-items-center justify-content-center">
                    <span class="material-icons-sharp text-white">notifications</span>
                </div>
                <div class="content w-100 d-flex justify-content-between align-items-center">
                    <div class="info">
                        <h3 class="m-0 fs-6">${title}</h3>
                        <small class="text-muted">${formattedDate}</small>
                    </div>
                    <span class="material-icons-sharp delete-reminder">delete</span>
                </div>
            `;
            
            remindersList.appendChild(newReminder);
            addReminderForm.style.display = 'none';
            addReminderBtn.style.display = 'flex';
            document.getElementById('reminder-title').value = '';
            document.getElementById('reminder-date').value = '';
            
            // Add event listener to new delete button
            newReminder.querySelector('.delete-reminder').addEventListener('click', function() {
                this.closest('.notification').remove();
            });
        } else {
            alert('Please fill in all fields');
        }
    });

    // Delete reminder
    document.querySelectorAll('.delete-reminder').forEach(btn => {
        btn.addEventListener('click', function() {
            this.closest('.notification').remove();
        });
    });
});
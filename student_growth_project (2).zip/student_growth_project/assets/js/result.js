 // Semester filter functionality
 document.addEventListener('DOMContentLoaded', function() {
    const semesterButtons = document.querySelectorAll('.semester-btn');
    const gradeCards = document.querySelectorAll('.grade-card');
    
    semesterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            semesterButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');
            
            const semester = this.getAttribute('data-semester');
            
            // Show/hide grade cards based on selection
            gradeCards.forEach(card => {
                if (semester === 'all' || card.getAttribute('data-semester') === semester) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
    
});
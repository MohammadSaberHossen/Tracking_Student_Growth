        // Sidebar toggle for mobile view
        const sideMenu = document.querySelector('aside');
        const menuBtn = document.getElementById('menu-btn');
        const closeBtn = document.getElementById('close-btn');

        menuBtn.addEventListener('click', () => {
            sideMenu.style.display = 'block';
            sideMenu.style.position = 'fixed';
            sideMenu.style.zIndex = '1000';
        });

        closeBtn.addEventListener('click', () => {
            sideMenu.style.display = 'none';
        });
        // Filter notices function
        function filterNotices() {
            const semesterFilter = document.getElementById('filterSemester').value;
            const priorityFilter = document.getElementById('filterPriority').value;
            const searchText = document.getElementById('searchNotice').value.toLowerCase();
            
            document.querySelectorAll('.notice-card').forEach(card => {
                const semester = card.getAttribute('data-semester') || '';
                const priority = card.getAttribute('data-priority') || 'normal';
                const title = card.querySelector('h4').textContent.toLowerCase();
                const content = card.querySelector('p').textContent.toLowerCase();
                
                const semesterMatch = semesterFilter === 'all' || semester === semesterFilter;
                const priorityMatch = priorityFilter === 'all' || priority === priorityFilter;
                const searchMatch = searchText === '' || 
                    title.includes(searchText) || 
                    content.includes(searchText);
                
                if (semesterMatch && priorityMatch && searchMatch) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }
        
        // Initialize event listeners for filtering
        document.getElementById('filterSemester').addEventListener('change', filterNotices);
        document.getElementById('filterPriority').addEventListener('change', filterNotices);
        document.getElementById('searchNotice').addEventListener('input', filterNotices);
        
        // Initialize the filter on page load
        document.addEventListener('DOMContentLoaded', filterNotices);
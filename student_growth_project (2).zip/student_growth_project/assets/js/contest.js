
         // Sidebar toggle for mobile view
         const sideMenu = document.querySelector('aside');
         const menuBtn = document.getElementById('menu-btn');
         const closeBtn = document.getElementById('close-btn');
 
         menuBtn.addEventListener('click', () => {
             sideMenu.style.display = 'block';
             sideMenu.style.position = 'fixed';
             sideMenu.style.zIndex = '1000';
         });
 
         closeBtn.addEventListener('click', () => {
             sideMenu.style.display = 'none';
         });
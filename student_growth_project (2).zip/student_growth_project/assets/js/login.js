// Toggle between Sign In and Sign Up forms
const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});

// Function to handle user type switching
function switchUserType(type) {
    // Get all elements that need to be updated
    const teacherSwitches = document.querySelectorAll('#switchToTeacher');
    const studentSwitches = document.querySelectorAll('#switchToStudent');
    const userTypeInputs = document.querySelectorAll('#userType');
    const loginId = document.getElementById('loginId');
    const signupId = document.getElementById('signupId');
    
    if (type === 'teacher') {
        // Update UI for all teacher switches
        teacherSwitches.forEach(switchEl => switchEl.classList.add('active'));
        studentSwitches.forEach(switchEl => switchEl.classList.remove('active'));
        
        // Update placeholders
        if (loginId) loginId.placeholder = "Teacher ID";
        if (signupId) signupId.placeholder = "Teacher ID";
        
        // Update hidden fields
        userTypeInputs.forEach(input => input.value = "teacher");
    } else {
        // Update UI for all student switches
        studentSwitches.forEach(switchEl => switchEl.classList.add('active'));
        teacherSwitches.forEach(switchEl => switchEl.classList.remove('active'));
        
        // Update placeholders
        if (loginId) loginId.placeholder = "Student ID";
        if (signupId) signupId.placeholder = "Student ID";
        
        // Update hidden fields
        userTypeInputs.forEach(input => input.value = "student");
    }
}

// Add event listeners for all teacher/student switches
document.querySelectorAll('#switchToTeacher').forEach(switchEl => {
    switchEl.addEventListener('click', function(e) {
        e.preventDefault();
        switchUserType('teacher');
    });
});

document.querySelectorAll('#switchToStudent').forEach(switchEl => {
    switchEl.addEventListener('click', function(e) {
        e.preventDefault();
        switchUserType('student');
    });
});

// Add this to your existing JavaScript code

// Password validation function
function validatePassword(password) {
    return password.length >= 6;
}

// Sign Up form validation
document.querySelector('.sign-up form').addEventListener('submit', function(e) {
    const password = this.querySelector('input[name="password"]').value;
    const confirmPassword = this.querySelector('input[name="confirm_password"]').value;
    
    if (!validatePassword(password)) {
        alert('Password must be at least 6 characters long');
        e.preventDefault();
        return;
    }
    
    if (password !== confirmPassword) {
        alert('Passwords do not match');
        e.preventDefault();
    }
});

// Sign In form validation
document.querySelector('.sign-in form').addEventListener('submit', function(e) {
    const password = this.querySelector('input[name="password"]').value;
    
    if (!validatePassword(password)) {
        alert('Password must be at least 6 characters long');
        e.preventDefault();
    }
});
 // Semester tab switching
 document.querySelectorAll('.semester-tab').forEach(tab => {
    tab.addEventListener('click', function() {
        // Remove active class from all tabs
        document.querySelectorAll('.semester-tab').forEach(t => t.classList.remove('active'));
        // Add active class to clicked tab
        this.classList.add('active');
        
        // Hide all attendance cards
        document.querySelectorAll('.attendance-card').forEach(card => {
            card.style.display = 'none';
        });
        
        // Show selected semester's card
        const semester = this.getAttribute('data-semester');
        document.querySelector(`.attendance-card[data-semester="${semester}"]`).style.display = 'block';
    });
});

        // Sidebar toggle for mobile view
        const sideMenu = document.querySelector('aside');
        const menuBtn = document.getElementById('menu-btn');
        const closeBtn = document.getElementById('close-btn');

        menuBtn.addEventListener('click', () => {
            sideMenu.style.display = 'block';
            sideMenu.style.position = 'fixed';
            sideMenu.style.zIndex = '1000';
        });

        closeBtn.addEventListener('click', () => {
            sideMenu.style.display = 'none';
        });
              // Sidebar toggle for mobile view
              const sideMenu = document.querySelector('aside');
              const menuBtn = document.getElementById('menu-btn');
              const closeBtn = document.getElementById('close-btn');
      
              menuBtn.addEventListener('click', () => {
                  sideMenu.style.display = 'block';
                  sideMenu.style.position = 'fixed';
                  sideMenu.style.zIndex = '1000';
              });
      
              closeBtn.addEventListener('click', () => {
                  sideMenu.style.display = 'none';
              });
              // Load submission details via AJAX when view button is clicked
              document.querySelectorAll('.view-submission').forEach(button => {
                  button.addEventListener('click', function() {
                      const submissionId = this.getAttribute('data-submission-id');
                      const modalContent = document.getElementById('submissionModalContent');
                      
                      // Show loading spinner
                      modalContent.innerHTML = `
                          <div class="text-center my-5">
                              <div class="spinner-border text-primary" role="status">
                                  <span class="visually-hidden">Loading...</span>
                              </div>
                          </div>
                      `;
                      
                      // Fetch submission details
                      fetch(`get_submission.php?id=${submissionId}`)
                          .then(response => response.text())
                          .then(data => {
                              modalContent.innerHTML = data;
                          })
                          .catch(error => {
                              modalContent.innerHTML = `
                                  <div class="alert alert-danger">
                                      Error loading submission details. Please try again.
                                  </div>
                              `;
                              console.error('Error:', error);
                          });
                  });
              });
              
              // Reset modal content when closed
              document.getElementById('viewSubmissionModal').addEventListener('hidden.bs.modal', function () {
                  document.getElementById('submissionModalContent').innerHTML = `
                      <div class="text-center my-5">
                          <div class="spinner-border text-primary" role="status">
                              <span class="visually-hidden">Loading...</span>
                          </div>
                      </div>
                  `;
              });
              
              // Initialize datetime pickers for contest creation
              document.addEventListener('DOMContentLoaded', function() {
                  // Set default start time to now
                  const now = new Date();
                  const startTimeInput = document.getElementById('start-time');
                  const endTimeInput = document.getElementById('end-time');
                  
                  // Format to YYYY-MM-DDTHH:MM (local datetime format)
                  const formattedNow = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
                  const formattedFuture = new Date(now.getTime() + 2 * 60 * 60 * 1000 - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
                  
                  startTimeInput.value = formattedNow;
                  endTimeInput.value = formattedFuture;
                  
                  // Validate end time is after start time
                  startTimeInput.addEventListener('change', function() {
                      if (new Date(endTimeInput.value) <= new Date(startTimeInput.value)) {
                          const newEndTime = new Date(new Date(startTimeInput.value).getTime() + 2 * 60 * 60 * 1000);
                          endTimeInput.value = newEndTime.toISOString().slice(0, 16);
                      }
                  });
              });

         // Sidebar toggle for mobile view
         const sideMenu = document.querySelector('aside');
         const menuBtn = document.getElementById('menu-btn');
         const closeBtn = document.getElementById('close-btn');
 
         menuBtn.addEventListener('click', () => {
             sideMenu.style.display = 'block';
             sideMenu.style.position = 'fixed';
             sideMenu.style.zIndex = '1000';
         });
 
         closeBtn.addEventListener('click', () => {
             sideMenu.style.display = 'none';
         });
        document.addEventListener('DOMContentLoaded', function() {
            
            // Calculate percentage when attended classes or total classes change
            document.querySelectorAll('.attended-classes, .total-classes input').forEach(input => {
                input.addEventListener('input', function() {
                    const semesterCard = this.closest('.semester-card');
                    let attended = parseInt(semesterCard.querySelector('.attended-classes').value) || 0;
                    let total = parseInt(semesterCard.querySelector('.total-classes input').value) || 1; // Default to 1 if total is 0
                    
                    // Ensure attended doesn't exceed total
                    if (attended > total) {
                        semesterCard.querySelector('.attended-classes').value = total;
                        attended = total;
                    }
                    
                    // Calculate percentage (with safeguard against division by zero)
                    const percentage = total > 0 ? Math.round((attended / total) * 100) : 0;
                    
                    // Update display
                    semesterCard.querySelector('.percentage-value').textContent = percentage + '%';
                    const progressBar = semesterCard.querySelector('.progress-bar');
                    progressBar.style.width = percentage + '%';
                    
                    // Change color based on percentage
                    if (percentage < 75) {
                        progressBar.style.backgroundColor = 'var(--color-danger)';
                    } else if (percentage < 90) {
                        progressBar.style.backgroundColor = 'var(--color-warning)';
                    } else {
                        progressBar.style.backgroundColor = 'var(--color-success)';
                    }
                });
            });
        });
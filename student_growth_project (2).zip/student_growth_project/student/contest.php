<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in and is a student
checkAuth();
$user = getCurrentUser($pdo);
if ($user['user_type'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

// Get student contests
$stmt = $pdo->prepare("SELECT cs.*, c.title, c.start_time, c.end_time 
                      FROM contest_submissions cs
                      JOIN contests c ON cs.contest_id = c.contest_id
                      WHERE cs.student_id = ?");
$stmt->execute([$user['user_id']]);
$contests = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all available contests
$availableContests = $pdo->query("SELECT * FROM contests WHERE end_time > NOW() ORDER BY start_time ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contest | PU</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link href="../assets/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/contest.css">
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar Section -->
            <aside class="col-md-2">
                <div class="toggle d-flex justify-content-between align-items-center mt-3">
                    <div class="logo d-flex align-items-center gap-2">
                        <img src="../assets/image/Logo_of_Premier_University_(PU).png" class="img-fluid" width="64" height="64" alt="PU Logo">
                        <h2 class="m-0">PU<span class="danger">C</span></h2>
                    </div>
                    <div class="close" id="close-btn">
                        <span class="material-icons-sharp">close</span>
                    </div>
                </div>

                <div class="sidebar bg-white shadow rounded-3 p-3 mt-4 h-88vh position-relative">
                    <a href="../index.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">dashboard</span>
                        <h3 class="m-0 ms-2">Home</h3>
                    </a>
                    <a href="contest.php" class="active d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">insights</span>
                        <h3 class="m-0 ms-2">Contest</h3>
                    </a>
                    <a href="attendance.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">calendar_today</span>
                        <h3 class="m-0 ms-2">Attendance</h3>
                    </a>
                    <a href="result.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">inventory</span>
                        <h3 class="m-0 ms-2">Result</h3>
                    </a>
                    <a href="notice.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">mail_outline</span>
                        <h3 class="m-0 ms-2">Notice</h3>
                    </a>
                    <a href="profile.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">settings</span>
                        <h3 class="m-0 ms-2">Edit Profile</h3>
                    </a>
                    <a href="../logout.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded position-absolute bottom-0 start-0 w-100">
                        <span class="material-icons-sharp">logout</span>
                        <h3 class="m-0 ms-2">Logout</h3>
                    </a>
                </div>
            </aside>
            <!-- End of Sidebar Section -->

            <!-- Main Content -->
            <main class="col-md-10">
                <div class="contest-header d-flex justify-content-between align-items-center border-bottom border-2 border-secondary pb-3 mb-4">
                    <h1 class="fw-bold fs-3">Programming Contest</h1>
                </div>

                <!-- Contest Tabs -->
                <ul class="nav nav-tabs mb-4" id="contestTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="available-tab" data-bs-toggle="tab" data-bs-target="#available" type="button" role="tab">Available Contests</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="participate-tab" data-bs-toggle="tab" data-bs-target="#participate" type="button" role="tab">Participate</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="result-tab" data-bs-toggle="tab" data-bs-target="#result" type="button" role="tab">Result</button>
                    </li>
                </ul>

                <!-- Tab Contents -->
                <div class="tab-content" id="contestTabContent">
                    <!-- Available Contests Tab -->
                    <div class="tab-pane fade" id="available" role="tabpanel">
                        <div class="available-contests">
                            <div class="d-flex justify-content-between align-items-center mb-4">
                                <h3 class="m-0">Available Contests</h3>
                                <button class="btn btn-primary" id="refreshContestsBtn">
                                    <span class="material-icons-sharp me-1">refresh</span> Refresh
                                </button>
                            </div>
                            
                            <div class="contest-list">
                                <!-- Active Contests -->
                                <h5 class="mb-3">Active Contests</h5>
                                <?php foreach($availableContests as $contest): 
                                    $now = new DateTime();
                                    $startTime = new DateTime($contest['start_time']);
                                    $endTime = new DateTime($contest['end_time']);
                                    $isActive = ($now >= $startTime && $now <= $endTime);
                                    $isUpcoming = ($now < $startTime);
                                ?>
                                <?php if($isActive): ?>
                                <div class="contest-card position-relative">
                                    <span class="badge bg-success status-badge">Active</span>
                                    <div class="contest-details">
                                        <h4><?= htmlspecialchars($contest['title']) ?></h4>
                                        <p class="text-muted">By: <?= htmlspecialchars($contest['teacher_name'] ?? 'Dr. Mohammad Hasan') ?></p>
                                        <div class="d-flex gap-4">
                                            <div>
                                                <small class="text-muted">Start Time</small>
                                                <p class="m-0"><?= date('F j, Y - g:i A', strtotime($contest['start_time'])) ?></p>
                                            </div>
                                            <div>
                                                <small class="text-muted">End Time</small>
                                                <p class="m-0"><?= date('F j, Y - g:i A', strtotime($contest['end_time'])) ?></p>
                                            </div>
                                            <div>
                                                <small class="text-muted">Duration</small>
                                                <p class="m-0"><?= gmdate("H:i", strtotime($contest['duration'] ?? '01:30:00')) ?> hours</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="contest-actions">
                                        <button class="btn btn-outline-secondary">
                                            <span class="material-icons-sharp me-1">info</span> Details
                                        </button>
                                        <button class="btn btn-primary join-contest-btn" data-contest-id="<?= $contest['contest_id'] ?>">
                                            <span class="material-icons-sharp me-1">login</span> Join Contest
                                        </button>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; ?>
                                
                                <!-- Upcoming Contests -->
                                <h5 class="mb-3 mt-4">Upcoming Contests</h5>
                                <?php foreach($availableContests as $contest): 
                                    $now = new DateTime();
                                    $startTime = new DateTime($contest['start_time']);
                                    $isUpcoming = ($now < $startTime);
                                ?>
                                <?php if($isUpcoming): ?>
                                <div class="contest-card position-relative">
                                    <span class="badge bg-warning text-dark status-badge">Upcoming</span>
                                    <div class="contest-details">
                                        <h4><?= htmlspecialchars($contest['title']) ?></h4>
                                        <p class="text-muted">By: <?= htmlspecialchars($contest['teacher_name'] ?? 'Prof. Ayesha Rahman') ?></p>
                                        <div class="d-flex gap-4">
                                            <div>
                                                <small class="text-muted">Start Time</small>
                                                <p class="m-0"><?= date('F j, Y - g:i A', strtotime($contest['start_time'])) ?></p>
                                            </div>
                                            <div>
                                                <small class="text-muted">End Time</small>
                                                <p class="m-0"><?= date('F j, Y - g:i A', strtotime($contest['end_time'])) ?></p>
                                            </div>
                                            <div>
                                                <small class="text-muted">Duration</small>
                                                <p class="m-0"><?= gmdate("H:i", strtotime($contest['duration'] ?? '02:00:00')) ?> hours</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="contest-actions">
                                        <button class="btn btn-outline-secondary">
                                            <span class="material-icons-sharp me-1">info</span> Details
                                        </button>
                                        <button class="btn btn-outline-primary" disabled>
                                            <span class="material-icons-sharp me-1">schedule</span> Starts Soon
                                        </button>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; ?>
                                
                                <!-- Past Contests -->
                                <h5 class="mb-3 mt-4">Past Contests</h5>
                                <?php 
                                $pastContests = $pdo->query("SELECT * FROM contests WHERE end_time < NOW() ORDER BY end_time DESC")->fetchAll(PDO::FETCH_ASSOC);
                                foreach($pastContests as $contest): 
                                ?>
                                <div class="contest-card position-relative">
                                    <span class="badge bg-secondary status-badge">Completed</span>
                                    <div class="contest-details">
                                        <h4><?= htmlspecialchars($contest['title']) ?></h4>
                                        <p class="text-muted">By: <?= htmlspecialchars($contest['teacher_name'] ?? 'Dr. Kamal Hossain') ?></p>
                                        <div class="d-flex gap-4">
                                            <div>
                                                <small class="text-muted">Start Time</small>
                                                <p class="m-0"><?= date('F j, Y - g:i A', strtotime($contest['start_time'])) ?></p>
                                            </div>
                                            <div>
                                                <small class="text-muted">End Time</small>
                                                <p class="m-0"><?= date('F j, Y - g:i A', strtotime($contest['end_time'])) ?></p>
                                            </div>
                                            <div>
                                                <small class="text-muted">Your Score</small>
                                                <?php 
                                                $scoreStmt = $pdo->prepare("SELECT score FROM contest_submissions WHERE contest_id = ? AND student_id = ?");
                                                $scoreStmt->execute([$contest['contest_id'], $user['user_id']]);
                                                $score = $scoreStmt->fetchColumn();
                                                ?>
                                                <p class="m-0"><?= $score ? $score . '/100' : 'Not attempted' ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="contest-actions">
                                        <button class="btn btn-outline-secondary">
                                            <span class="material-icons-sharp me-1">info</span> Details
                                        </button>
                                        <?php if($score !== false): ?>
                                        <button class="btn btn-success view-result-btn" data-contest-id="<?= $contest['contest_id'] ?>">
                                            <span class="material-icons-sharp me-1">visibility</span> View Results
                                        </button>
                                        <?php else: ?>
                                        <button class="btn btn-outline-secondary" disabled>
                                            <span class="material-icons-sharp me-1">visibility_off</span> Not Attempted
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Participate Tab -->
                    <div class="tab-pane fade show active" id="participate" role="tabpanel">
                        <?php
                        // Check if student has any active contest
                        $activeContestStmt = $pdo->prepare("SELECT c.* FROM contests c 
                                                           JOIN contest_submissions cs ON c.contest_id = cs.contest_id
                                                           WHERE cs.student_id = ? AND c.start_time <= NOW() AND c.end_time >= NOW()");
                        $activeContestStmt->execute([$user['user_id']]);
                        $activeContest = $activeContestStmt->fetch(PDO::FETCH_ASSOC);
                        ?>
                        
                        <?php if(!$activeContest): ?>
                        <!-- Contest Not Joined State -->
                        <div class="not-joined-state text-center py-5 bg-light rounded-3" id="notJoinedState">
                            <span class="material-icons-sharp text-muted" style="font-size: 5rem;">code</span>
                            <h3 class="my-3">No Active Contest</h3>
                            <p class="text-muted mb-4">Please join a contest from the Available Contests tab to participate</p>
                            <button class="btn btn-primary" onclick="document.getElementById('available-tab').click()">
                                <span class="material-icons-sharp me-1">list</span> View Available Contests
                            </button>
                        </div>
                        <?php else: ?>
                        <!-- Contest Joined State -->
                        <div class="joined-state" id="joinedState">
                            <?php
                            // Get contest problems
                            $problemsStmt = $pdo->prepare("SELECT * FROM contest_problems WHERE contest_id = ?");
                            $problemsStmt->execute([$activeContest['contest_id']]);
                            $problems = $problemsStmt->fetchAll(PDO::FETCH_ASSOC);
                            
                            // Calculate remaining time
                            $endTime = new DateTime($activeContest['end_time']);
                            $now = new DateTime();
                            $timeRemaining = $endTime->getTimestamp() - $now->getTimestamp();
                            ?>
                            
                            <div class="d-flex justify-content-between align-items-center mb-4 p-3 bg-white rounded-3 shadow-sm">
                                <div>
                                    <h3 class="m-0 fs-5" id="contestTitle"><?= htmlspecialchars($activeContest['title']) ?></h3>
                                    <small class="text-muted" id="contestTeacher">By: <?= htmlspecialchars($activeContest['teacher_name'] ?? 'Dr. Mohammad Hasan') ?></small>
                                </div>
                                <div class="text-end">
                                    <div class="timer fs-4 fw-bold text-primary" id="contestTimer">00:00:00</div>
                                    <small>Time Remaining</small>
                                </div>
                            </div>

                            <div class="contest-problems mb-4">
                                <?php foreach($problems as $index => $problem): 
                                    $problemNumber = $index + 1;
                                ?>
                                <div class="contest-problem">
                                    <div class="problem-header" onclick="toggleProblem(<?= $problemNumber ?>)">
                                        <h4 class="m-0">Problem <?= $problemNumber ?>: <?= htmlspecialchars($problem['title']) ?></h4>
                                    </div>
                                    <div class="problem-content" id="problemContent<?= $problemNumber ?>">
                                        <div class="problem-description mb-4">
                                            <h5>Description:</h5>
                                            <p><?= nl2br(htmlspecialchars($problem['description'])) ?></p>
                                            
                                            <h5>Input Format:</h5>
                                            <p><?= nl2br(htmlspecialchars($problem['input_format'])) ?></p>
                                            
                                            <h5>Output Format:</h5>
                                            <p><?= nl2br(htmlspecialchars($problem['output_format'])) ?></p>
                                            
                                            <h5>Constraints:</h5>
                                            <p><?= nl2br(htmlspecialchars($problem['constraints'])) ?></p>
                                            
                                            <h5>Example:</h5>
                                            <div class="bg-light p-2 rounded">
                                                <p class="m-0">Input: <?= htmlspecialchars($problem['sample_input']) ?></p>
                                                <p class="m-0">Output: <?= htmlspecialchars($problem['sample_output']) ?></p>
                                            </div>
                                        </div>
                                        
                                        <div class="solution-section">
                                            <h5>Your Solution:</h5>
                                            <select class="form-select mb-3" id="languageSelect<?= $problemNumber ?>">
                                                <option value="python">Python</option>
                                                <option value="java">Java</option>
                                                <option value="cpp">C++</option>
                                                <option value="c">C</option>
                                            </select>
                                            
                                            <div class="code-editor" id="editor<?= $problemNumber ?>"><?= htmlspecialchars($problem['default_code'] ?? '# Write your code here') ?></div>
                                            
                                            <div class="d-flex justify-content-between mt-3">
                                                <button class="btn btn-outline-primary" onclick="runTestCases(<?= $problemNumber ?>)">
                                                    <span class="material-icons-sharp me-1">play_arrow</span> Run Test Cases
                                                </button>
                                                <button class="btn btn-success" onclick="submitSolution(<?= $problemNumber ?>, <?= $problem['problem_id'] ?>)">
                                                    <span class="material-icons-sharp me-1">save</span> Submit Solution
                                                </button>
                                            </div>
                                            
                                            <div class="test-results mt-3" id="testResults<?= $problemNumber ?>" style="display: none;">
                                                <h5>Test Results:</h5>
                                                <!-- Will be populated by JavaScript -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>

                            <div class="contest-actions bg-white p-3 rounded-3 shadow-sm d-flex justify-content-between">
                                <button class="btn btn-outline-danger" id="leaveContestBtn">
                                    <span class="material-icons-sharp me-1">exit_to_app</span> Leave Contest
                                </button>
                                <button class="btn btn-primary" id="finalSubmitBtn" data-contest-id="<?= $activeContest['contest_id'] ?>">
                                    <span class="material-icons-sharp me-1">done_all</span> Final Submit
                                </button>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Result Tab -->
                    <div class="tab-pane fade" id="result" role="tabpanel">
                        <div class="result-container">
                            <h3>Your Contest Results</h3>
                            <?php if(empty($contests)): ?>
                            <div class="alert alert-info">
                                You haven't participated in any contests yet.
                            </div>
                            <?php else: ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Contest</th>
                                        <th>Score</th>
                                        <th>Submission Time</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($contests as $contest): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($contest['title']) ?></td>
                                        <td><?= $contest['score'] !== null ? $contest['score'] . '/100' : 'Not graded' ?></td>
                                        <td><?= date('M j, Y - g:i A', strtotime($contest['submission_time'])) ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-primary view-result-btn" data-submission-id="<?= $contest['submission_id'] ?>">
                                                View Details
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </main>
            <!-- End of Main Content -->
            <div class="right-section col-md-2 mt-4">
                <div class="nav d-flex justify-content-end gap-4">
                    <button id="menu-btn" class="btn p-0">
                        <span class="material-icons-sharp">menu</span>
                    </button>
                </div>
                <!-- End of Nav -->
            </div>
        </div>
    </div>

    <!-- Result Modal -->
    <div class="modal fade" id="resultModal" tabindex="-1" aria-labelledby="resultModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="resultModalLabel">Submission Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="resultModalBody">
                    Loading...
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/contest.js"></script>
</body>

</html>
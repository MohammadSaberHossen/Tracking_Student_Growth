<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in and is a student
checkAuth();
$user = getCurrentUser($pdo);
if ($user['user_type'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

// Get student details
$stmt = $pdo->prepare("SELECT s.*, u.* FROM students s JOIN users u ON s.user_id = u.user_id WHERE s.user_id = ?");
$stmt->execute([$user['user_id']]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    
    // Update user table
    $stmt = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, gender = ?, dob = ? WHERE user_id = ?");
    $stmt->execute([$firstName, $lastName, $email, $phone, $gender, $dob, $user['user_id']]);
    
    // Handle password change if provided
    if (!empty($_POST['current_password']) && !empty($_POST['new_password'])) {
        if (password_verify($_POST['current_password'], $student['password'])) {
            $newPassword = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
            $stmt->execute([$newPassword, $user['user_id']]);
        } else {
            $error = "Current password is incorrect";
        }
    }
    
    // Handle profile image upload
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/profile_images/';
        
        // Create directory if it doesn't exist
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        // Validate file
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
        $detectedType = finfo_file($fileInfo, $_FILES['profile_image']['tmp_name']);
        
        if (!in_array($detectedType, $allowedTypes)) {
            $error = "Invalid file type. Only JPG, PNG, and GIF images are allowed.";
        } elseif ($_FILES['profile_image']['size'] > 2 * 1024 * 1024) {
            $error = "File size must be less than 2MB";
        } else {
            // Generate unique filename
            $extension = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
            $imageName = uniqid() . '.' . $extension;
            $targetPath = $uploadDir . $imageName;
            
            // Delete old image if it exists
            if (!empty($student['profile_image']) && file_exists($uploadDir . $student['profile_image'])) {
                unlink($uploadDir . $student['profile_image']);
            }
            
            // Move uploaded file
            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $targetPath)) {
                $stmt = $pdo->prepare("UPDATE users SET profile_image = ? WHERE user_id = ?");
                $stmt->execute([$imageName, $user['user_id']]);
                // Update the student array to show the new image immediately
                $student['profile_image'] = $imageName;
            } else {
                $error = "Failed to upload image. Please try again.";
            }
        }
    } elseif (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $error = "File upload error: " . $this->getUploadError($_FILES['profile_image']['error']);
    }
    
    // Only redirect if there were no errors
    if (!isset($error)) {
        header("Location: profile.php");
        exit();
    }
}

function getUploadError($errorCode) {
    $errors = [
        UPLOAD_ERR_INI_SIZE => 'File is too large (server limit)',
        UPLOAD_ERR_FORM_SIZE => 'File is too large (form limit)',
        UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
        UPLOAD_ERR_NO_FILE => 'No file was uploaded',
        UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
        UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
        UPLOAD_ERR_EXTENSION => 'File upload stopped by extension'
    ];
    return $errors[$errorCode] ?? 'Unknown upload error';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link href="../assets/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/profile.css">
    <title>Edit Profile | PU</title>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar Section -->
            <aside class="col-md-2">
                <div class="toggle d-flex justify-content-between align-items-center mt-3">
                    <div class="logo d-flex align-items-center gap-2">
                        <img src="../assets/image/Logo_of_Premier_University_(PU).png" class="img-fluid" width="64" height="64">
                        <h2 class="m-0">PU<span class="danger">C</span></h2>
                    </div>
                    <div class="close" id="close-btn">
                        <span class="material-icons-sharp">close</span>
                    </div>
                </div>

                <div class="sidebar bg-white shadow rounded-3 p-3 mt-4 h-88vh position-relative">
                    <a href="../index.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">dashboard</span>
                        <h3 class="m-0 ms-2">Home</h3>
                    </a>
                    <a href="contest.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">insights</span>
                        <h3 class="m-0 ms-2">Contest</h3>
                    </a>
                    <a href="attendance.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">calendar_today</span>
                        <h3>Attendance</h3>
                    </a>
                    <a href="result.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">inventory</span>
                        <h3 class="m-0 ms-2">Result</h3>
                    </a>
                    <a href="notice.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">mail_outline</span>
                        <h3>Notice</h3>
                    </a>
                    <a href="profile.php" class="active d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">settings</span>
                        <h3 class="m-0 ms-2">Edit Profile</h3>
                    </a>
                    <a href="../logout.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded position-absolute bottom-0 start-0 w-100">
                        <span class="material-icons-sharp">logout</span>
                        <h3 class="m-0 ms-2">Logout</h3>
                    </a>
                </div>
            </aside>
            <!-- End of Sidebar Section -->

            <!-- Main Content -->
            <main class="col-md-10">
                <div class="profile-container">
                    <div class="profile-header">
                        <h1 class="fw-bold fs-3 mt-4 d-flex align-items-center">
                            <span class="material-icons-sharp mr-2">settings</span>
                            Edit Profile
                        </h1>
                    </div>
                    
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($_GET['success']) && $_GET['success'] == '1'): ?>
                        <div class="alert alert-success">Profile updated successfully!</div>
                    <?php endif; ?>
                    
                    <form method="POST" enctype="multipart/form-data" class="profile-form">
                        <!-- Profile Photo Upload -->
                        <div class="photo-upload">
                            <img src="<?= !empty($student['profile_image']) ? '../uploads/profile_images/' . htmlspecialchars($student['profile_image']) : '../assets/image/default-profile.jpg' ?>" 
                                 alt="Profile Photo" class="profile-photo" id="profileImagePreview">
                            <label for="profile_image" class="upload-btn">
                                <span class="material-icons-sharp">photo_camera</span>
                                Upload Photo
                            </label>
                            <input type="file" id="profile_image" name="profile_image" accept="image/jpeg, image/png, image/gif" style="display: none;">
                            <small class="text-muted d-block mt-1">Max size: 2MB (JPEG, PNG, GIF)</small>
                        </div>
                        
                        <!-- Personal Information -->
                        <div class="form-group">
                            <label for="first_name">First Name</label>
                            <input type="text" id="first_name" name="first_name" class="form-control" 
                                   value="<?= htmlspecialchars($student['first_name']) ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="last_name">Last Name</label>
                            <input type="text" id="last_name" name="last_name" class="form-control" 
                                   value="<?= htmlspecialchars($student['last_name']) ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" class="form-control" 
                                   value="<?= htmlspecialchars($student['email']) ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" class="form-control" 
                                   value="<?= htmlspecialchars($student['phone']) ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="dob">Date of Birth</label>
                            <input type="date" id="dob" name="dob" class="form-control" 
                                   value="<?= htmlspecialchars($student['dob']) ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="gender">Gender</label>
                            <select id="gender" name="gender" class="form-control">
                                <option value="male" <?= $student['gender'] == 'male' ? 'selected' : '' ?>>Male</option>
                                <option value="female" <?= $student['gender'] == 'female' ? 'selected' : '' ?>>Female</option>
                                <option value="other" <?= $student['gender'] == 'other' ? 'selected' : '' ?>>Other</option>
                            </select>
                        </div>
                        
                        <!-- Student Information -->
                        <div class="form-group">
                            <label for="roll_number">Roll Number</label>
                            <input type="text" id="roll_number" class="form-control" 
                                   value="<?= htmlspecialchars($student['roll_number']) ?>" readonly>
                        </div>
                        
                        <div class="form-group">
                            <label for="batch">Batch</label>
                            <input type="text" id="batch" class="form-control" 
                                   value="<?= htmlspecialchars($student['batch']) ?>" readonly>
                        </div>
                        
                        <div class="form-group">
                            <label for="semester">Semester</label>
                            <input type="text" id="semester" class="form-control" 
                                   value="<?= htmlspecialchars($student['semester']) ?>" readonly>
                        </div>
                        
                        <div class="form-group">
                            <label for="section">Section</label>
                            <input type="text" id="section" class="form-control" 
                                   value="<?= htmlspecialchars($student['section']) ?>" readonly>
                        </div>
                        
                        <!-- Password Change -->
                        <div class="form-group full-width">
                            <h3 class="d-flex align-items-center" style="color: var(--color-primary); margin-bottom: 1rem;">
                                <span class="material-icons-sharp mr-2">lock</span>
                                Change Password
                            </h3>
                        </div>
                        
                        <div class="form-group">
                            <label for="current_password">Current Password</label>
                            <input type="password" id="current_password" name="current_password" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label for="new_password">New Password</label>
                            <input type="password" id="new_password" name="new_password" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">Confirm Password</label>
                            <input type="password" id="confirm_password" name="confirm_password" class="form-control">
                        </div>
                        
                        <!-- Form Actions -->
                        <div class="form-actions">
                            <button type="reset" class="btn btn-outline">Cancel</button>
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            </main>
            <!-- End of Main Content -->
            <div class="right-section col-md-2 mt-4">
                <div class="nav d-flex justify-content-end gap-4">
                    <button id="menu-btn" class="btn p-0">
                        <span class="material-icons-sharp">menu</span>
                    </button>
                </div>
                <!-- End of Nav -->
            </div>
        </div>
    </div>

    <script src="../assets/bootstrap/bootstrap.bundle.min.js"></script>
    <script>
        
         // Sidebar toggle for mobile view
         const sideMenu = document.querySelector('aside');
         const menuBtn = document.getElementById('menu-btn');
         const closeBtn = document.getElementById('close-btn');
 
         menuBtn.addEventListener('click', () => {
             sideMenu.style.display = 'block';
             sideMenu.style.position = 'fixed';
             sideMenu.style.zIndex = '1000';
         });
 
         closeBtn.addEventListener('click', () => {
             sideMenu.style.display = 'none';
         });
        // Profile image preview
        document.getElementById('profile_image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                // Check file size (max 2MB)
                if (file.size > 2 * 1024 * 1024) {
                    alert('File size must be less than 2MB');
                    e.target.value = ''; // Clear the file input
                    return;
                }
                
                // Check file type
                const validTypes = ['image/jpeg', 'image/png', 'image/gif'];
                if (!validTypes.includes(file.type)) {
                    alert('Only JPG, PNG, and GIF images are allowed');
                    e.target.value = ''; // Clear the file input
                    return;
                }
                
                const reader = new FileReader();
                reader.onload = function(event) {
                    document.getElementById('profileImagePreview').src = event.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>
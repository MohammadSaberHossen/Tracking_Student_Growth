<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

checkAuth();
$user = getCurrentUser($pdo);

if ($user['user_type'] !== 'student') {
    header("Location: ../index.php");
    exit();
}

// Get student's results directly from results table
$results = $pdo->prepare("SELECT * FROM results 
                         WHERE student_id = ? AND published IN (0, 1)
                         ORDER BY semester, course_code");
$results->execute([$user['user_id']]);
$results = $results->fetchAll(PDO::FETCH_ASSOC);

// Organize results by semester
$semester_results = [];
foreach ($results as $result) {
    $semester = $result['semester'];
    if (!isset($semester_results[$semester])) {
        $semester_results[$semester] = [];
    }
    $semester_results[$semester][] = $result;
}

// Calculate CGPA
$total_credits = 0;
$total_grade_points = 0;

// Assuming each course has 3 credits (since we're not joining with courses table)
$credit_per_course = 3;

foreach ($results as $result) {
    $grade_point = 0;
    switch ($result['grade']) {
        case 'A+': $grade_point = 4.0; break;
        case 'A':  $grade_point = 3.75; break;
        case 'A-': $grade_point = 3.5; break;
        case 'B+': $grade_point = 3.25; break;
        case 'B':  $grade_point = 3.0; break;
        case 'B-': $grade_point = 2.75; break;
        case 'C+': $grade_point = 2.5; break;
        case 'C':  $grade_point = 2.25; break;
        case 'D':  $grade_point = 2.0; break;
        case 'F':  $grade_point = 0.0; break;
    }
    
    $total_grade_points += $grade_point * $credit_per_course;
    $total_credits += $credit_per_course;
}

$cgpa = $total_credits > 0 ? $total_grade_points / $total_credits : 0;

// Get active semester from query string
$active_semester = isset($_GET['semester']) ? $_GET['semester'] : 'all';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link href="../assets/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/result.css">
    <title>Result | PU</title>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar Section -->
            <aside class="col-md-2">
            <div class="toggle d-flex justify-content-between align-items-center mt-3">
                    <div class="logo d-flex align-items-center gap-2">
                        <img src="../assets/image/Logo_of_Premier_University_(PU).png" class="img-fluid" width="64" height="64">
                        <h2 class="m-0">PU<span class="danger">C</span></h2>
                    </div>
                    <div class="close" id="close-btn">
                        <span class="material-icons-sharp">close</span>
                    </div>
                </div>

                <div class="sidebar bg-white shadow rounded-3 p-3 mt-4 h-88vh position-relative">
                    <a href="../index.php" class="ad-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">dashboard</span>
                        <h3 class="m-0 ms-2">Home</h3>
                    </a>
                    <a href="contest.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">insights</span>
                        <h3 class="m-0 ms-2">Contest</h3>
                    </a>
                    <a href="attendance.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">calendar_today</span>
                        <h3>Attendance</h3>
                    </a>
                    <a href="result.php" class="active d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">inventory</span>
                        <h3 class="m-0 ms-2">Result</h3>
                    </a>
                    <a href="notice.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">mail_outline</span>
                        <h3>Notice</h3>
                    </a>
                    <a href="profile.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">settings</span>
                        <h3 class="m-0 ms-2">Edit Profile</h3>
                    </a>
                    <a href="../logout.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded position-absolute bottom-0 start-0 w-100">
                        <span class="material-icons-sharp">logout</span>
                        <h3 class="m-0 ms-2">Logout</h3>
                    </a>
                </div>
            </aside>
            <!-- End of Sidebar Section -->

            <!-- Main Content -->
            <main class="col-md-10">
                <div class="result-container">
                    <h1 class="fw-bold fs-3 mt-4">Semester Results</h1>
                    
                    <!-- Semester Selector -->
                    <div class="semester-selector no-print">
                        <button class="semester-btn <?= $active_semester === 'all' ? 'active' : '' ?>" 
                                onclick="window.location.href='result.php?semester=all'">All Semesters</button>
                        <?php for ($i = 1; $i <= 8; $i++): ?>
                            <button class="semester-btn <?= $active_semester == $i ? 'active' : '' ?>" 
                                    onclick="window.location.href='result.php?semester=<?= $i ?>'">
                                <?= $i . ($i == 1 ? 'st' : ($i == 2 ? 'nd' : ($i == 3 ? 'rd' : 'th'))) ?> Semester
                            </button>
                        <?php endfor; ?>
                    </div>
                    
                    <!-- Display results for selected semester -->
                    <?php if ($active_semester === 'all'): ?>
                        <?php foreach ($semester_results as $semester => $results): ?>
                            <div class="grade-card" data-semester="<?= $semester ?>">
                                <h3><?= $semester . ($semester == 1 ? 'st' : ($semester == 2 ? 'nd' : ($semester == 3 ? 'rd' : 'th'))) ?> Semester Result</h3>
                                <table class="grade-table">
                                    <thead>
                                        <tr>
                                            <th>Course Code</th>
                                            <th>Section</th>
                                            <th>Attendance</th>
                                            <th>Midterm</th>
                                            <th>Final</th>
                                            <th>Total</th>
                                            <th>Grade</th>
                                            <th>Points</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($results as $result): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($result['course_code']) ?></td>
                                                <td><?= htmlspecialchars($result['section']) ?></td>
                                                <td><?= $result['attendance'] ?></td>
                                                <td><?= $result['midterm'] ?></td>
                                                <td><?= $result['final'] ?></td>
                                                <td><?= $result['total'] ?></td>
                                                <td><?= $result['grade'] ?></td>
                                                <td>
                                                    <?php 
                                                    switch ($result['grade']) {
                                                        case 'A+': echo '4.00'; break;
                                                        case 'A':  echo '3.75'; break;
                                                        case 'A-': echo '3.50'; break;
                                                        case 'B+': echo '3.25'; break;
                                                        case 'B':  echo '3.00'; break;
                                                        case 'B-': echo '2.75'; break;
                                                        case 'C+': echo '2.50'; break;
                                                        case 'C':  echo '2.25'; break;
                                                        case 'D':  echo '2.00'; break;
                                                        case 'F':  echo '0.00'; break;
                                                    }
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                                
                                <div class="summary-card">
                                    <?php
                                    // Calculate semester GPA
                                    $semester_credits = 0;
                                    $semester_grade_points = 0;
                                    
                                    foreach ($results as $result) {
                                        $grade_point = 0;
                                        switch ($result['grade']) {
                                            case 'A+': $grade_point = 4.0; break;
                                            case 'A':  $grade_point = 3.75; break;
                                            case 'A-': $grade_point = 3.5; break;
                                            case 'B+': $grade_point = 3.25; break;
                                            case 'B':  $grade_point = 3.0; break;
                                            case 'B-': $grade_point = 2.75; break;
                                            case 'C+': $grade_point = 2.5; break;
                                            case 'C':  $grade_point = 2.25; break;
                                            case 'D':  $grade_point = 2.0; break;
                                            case 'F':  $grade_point = 0.0; break;
                                        }
                                        
                                        $semester_grade_points += $grade_point * $credit_per_course;
                                        $semester_credits += $credit_per_course;
                                    }
                                    
                                    $semester_gpa = $semester_credits > 0 ? $semester_grade_points / $semester_credits : 0;
                                    ?>
                                    <div class="summary-row">
                                        <strong>Semester GPA:</strong>
                                        <span><?= number_format($semester_gpa, 2) ?></span>
                                    </div>
                                    <div class="summary-row">
                                        <strong>Total Credits:</strong>
                                        <span><?= $semester_credits ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php elseif (isset($semester_results[$active_semester])): ?>
                        <div class="grade-card" data-semester="<?= $active_semester ?>">
                            <h3><?= $active_semester . ($active_semester == 1 ? 'st' : ($active_semester == 2 ? 'nd' : ($active_semester == 3 ? 'rd' : 'th'))) ?> Semester Result</h3>
                            <table class="grade-table">
                                <thead>
                                    <tr>
                                        <th>Course Code</th>
                                        <th>Section</th>
                                        <th>Attendance</th>
                                        <th>Midterm</th>
                                        <th>Final</th>
                                        <th>Total</th>
                                        <th>Grade</th>
                                        <th>Points</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($semester_results[$active_semester] as $result): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($result['course_code']) ?></td>
                                            <td><?= htmlspecialchars($result['section']) ?></td>
                                            <td><?= $result['attendance'] ?></td>
                                            <td><?= $result['midterm'] ?></td>
                                            <td><?= $result['final'] ?></td>
                                            <td><?= $result['total'] ?></td>
                                            <td><?= $result['grade'] ?></td>
                                            <td>
                                                <?php 
                                                switch ($result['grade']) {
                                                    case 'A+': echo '4.00'; break;
                                                    case 'A':  echo '3.75'; break;
                                                    case 'A-': echo '3.50'; break;
                                                    case 'B+': echo '3.25'; break;
                                                    case 'B':  echo '3.00'; break;
                                                    case 'B-': echo '2.75'; break;
                                                    case 'C+': echo '2.50'; break;
                                                    case 'C':  echo '2.25'; break;
                                                    case 'D':  echo '2.00'; break;
                                                    case 'F':  echo '0.00'; break;
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            
                            <div class="summary-card">
                                <?php
                                // Calculate semester GPA for the active semester
                                $semester_credits = 0;
                                $semester_grade_points = 0;
                                
                                foreach ($semester_results[$active_semester] as $result) {
                                    $grade_point = 0;
                                    switch ($result['grade']) {
                                        case 'A+': $grade_point = 4.0; break;
                                        case 'A':  $grade_point = 3.75; break;
                                        case 'A-': $grade_point = 3.5; break;
                                        case 'B+': $grade_point = 3.25; break;
                                        case 'B':  $grade_point = 3.0; break;
                                        case 'B-': $grade_point = 2.75; break;
                                        case 'C+': $grade_point = 2.5; break;
                                        case 'C':  $grade_point = 2.25; break;
                                        case 'D':  $grade_point = 2.0; break;
                                        case 'F':  $grade_point = 0.0; break;
                                    }
                                    
                                    $semester_grade_points += $grade_point * $credit_per_course;
                                    $semester_credits += $credit_per_course;
                                }
                                
                                $semester_gpa = $semester_credits > 0 ? $semester_grade_points / $semester_credits : 0;
                                ?>
                                <div class="summary-row">
                                    <strong>Semester GPA:</strong>
                                    <span><?= number_format($semester_gpa, 2) ?></span>
                                </div>
                                <div class="summary-row">
                                    <strong>Total Credits:</strong>
                                    <span><?= $semester_credits ?></span>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">No results found for this semester.</div>
                    <?php endif; ?>
                    
                    <!-- Overall Summary -->
                    <div class="grade-card no-print">
                        <h3>Overall Academic Summary</h3>
                        <div class="summary-card">
                            <div class="summary-row">
                                <strong>Current CGPA:</strong>
                                <span><?= number_format($cgpa, 2) ?></span>
                            </div>
                            <div class="summary-row">
                                <strong>Total Credits Completed:</strong>
                                <span><?= $total_credits ?></span>
                            </div>
                            <div class="summary-row">
                                <strong>Total Courses Completed:</strong>
                                <span><?= count($results) ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <button class="print-btn no-print" onclick="window.print()">
                        <span class="material-icons-sharp">print</span>
                        Print Result
                    </button>
                </div>
            </main>
            <!-- End of Main Content -->

            <div class="right-section col-md-2 mt-4">
                <div class="nav d-flex justify-content-end gap-4">
                    <button id="menu-btn" class="btn p-0">
                        <span class="material-icons-sharp">menu</span>
                    </button>
                </div>
                <!-- End of Nav -->
            </div>
        </div>
    </div>

    <script src="../assets/bootstrap/bootstrap.bundle.min.js"></script>
    <script>
        
         // Sidebar toggle for mobile view
         const sideMenu = document.querySelector('aside');
         const menuBtn = document.getElementById('menu-btn');
         const closeBtn = document.getElementById('close-btn');
 
         menuBtn.addEventListener('click', () => {
             sideMenu.style.display = 'block';
             sideMenu.style.position = 'fixed';
             sideMenu.style.zIndex = '1000';
         });
 
         closeBtn.addEventListener('click', () => {
             sideMenu.style.display = 'none';
         });
        // Semester filter functionality
        document.addEventListener('DOMContentLoaded', function() {
            const semesterButtons = document.querySelectorAll('.semester-btn');
            const gradeCards = document.querySelectorAll('.grade-card');
            
            // Highlight active semester button
            semesterButtons.forEach(button => {
                if (button.classList.contains('active')) {
                    button.style.backgroundColor = 'var(--color-primary)';
                    button.style.color = 'white';
                }
            });
        });
    </script>
</body>
</html>
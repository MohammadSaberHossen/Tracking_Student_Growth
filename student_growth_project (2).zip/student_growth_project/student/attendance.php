<?php
require_once '../includes/auth.php';
checkAuth();

$user = getCurrentUser($GLOBALS['pdo']);
if ($user['user_type'] !== 'student') {
    header("Location: " . ($user['user_type'] === 'teacher' ? "../teacher/teacher_dashboard.php" : "../login.php"));
    exit();
}

// Get student details
$stmt = $GLOBALS['pdo']->prepare("SELECT semester, section FROM students WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

// Get attendance by semester
$stmt = $GLOBALS['pdo']->prepare("SELECT semester, SUM(total_classes) as total, SUM(attended_classes) as attended 
                                 FROM attendance WHERE student_id = ? GROUP BY semester");
$stmt->execute([$_SESSION['user_id']]);
$attendance = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link href="../assets/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/attendance.css">
    <title>Attendance | PU</title>
    <style>
        
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar Section -->
            <aside class="col-md-2">
                <div class="toggle d-flex justify-content-between align-items-center mt-3">
                    <div class="logo d-flex align-items-center gap-2">
                        <img src="../assets/image/Logo_of_Premier_University_(PU).png" class="img-fluid" width="64" height="64">
                        <h2 class="m-0">PU<span class="danger">C</span></h2>
                    </div>
                    <div class="close" id="close-btn">
                        <span class="material-icons-sharp">close</span>
                    </div>
                </div>

                <div class="sidebar bg-white shadow rounded-3 p-3 mt-4 h-88vh position-relative">
                    <a href="../index.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">dashboard</span>
                        <h3 class="m-0 ms-2">Home</h3>
                    </a>
                    <a href="contest.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">insights</span>
                        <h3 class="m-0 ms-2">Contest</h3>
                    </a>
                    <a href="attendance.php" class="active d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">calendar_today</span>
                        <h3>Attendance</h3>
                    </a>
                    <a href="result.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">inventory</span>
                        <h3 class="m-0 ms-2">Result</h3>
                    </a>
                    <a href="notice.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">mail_outline</span>
                        <h3>Notice</h3>
                    </a>
                    <a href="profile.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">settings</span>
                        <h3 class="m-0 ms-2">Edit Profile</h3>
                    </a>
                    <a href="../logout.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded position-absolute bottom-0 start-0 w-100">
                        <span class="material-icons-sharp">logout</span>
                        <h3 class="m-0 ms-2">Logout</h3>
                    </a>
                </div>
            </aside>
            <!-- End of Sidebar Section -->

            <!-- Main Content -->
            <main class="col-md-10">
                <div class="attendance-container">
                    <h1 class="fw-bold fs-3 mt-4 d-flex align-items-center">
                        <span class="material-icons-sharp mr-2">calendar_today</span>
                        Semester Attendance
                    </h1>
                    
                    <!-- Semester Tabs -->
                    <div class="semester-tabs">
                        <?php foreach ($attendance as $a): ?>
                        <div class="semester-tab <?php echo $a['semester'] == $student['semester'] ? 'active' : ''; ?>" 
                             data-semester="<?php echo $a['semester']; ?>">
                            <?php echo $a['semester']; ?><?php echo getOrdinalSuffix($a['semester']); ?> Semester
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Attendance Cards -->
                    <?php foreach ($attendance as $a): 
                        $attended = $a['attended'];
                        $total = $a['total'];
                        $absent = $total - $attended;
                        $percentage = $total > 0 ? round(($attended/$total)*100) : 0;
                    ?>
                    <div class="attendance-card" data-semester="<?php echo $a['semester']; ?>"
                         style="<?php echo $a['semester'] == $student['semester'] ? '' : 'display: none;' ?>">
                        <h3>
                            <span class="material-icons-sharp">looks_<?php echo $a['semester']; ?></span>
                            <?php echo $a['semester']; ?><?php echo getOrdinalSuffix($a['semester']); ?> Semester Attendance
                        </h3>
                        
                        <div class="progress-container">
                            <div class="progress-info">
                                <span>Overall Attendance</span>
                                <span><?php echo $percentage; ?>% (<?php echo $attended; ?>/<?php echo $total; ?> classes)</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: <?php echo $percentage; ?>%"></div>
                            </div>
                        </div>
                        
                        <div class="attendance-stats">
                            <div class="stat-card">
                                <h4>Present Days</h4>
                                <p><?php echo $attended; ?> classes</p>
                            </div>
                            <div class="stat-card">
                                <h4>Absent Days</h4>
                                <p><?php echo $absent; ?> classes</p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </main>
            <!-- End of Main Content -->
            <div class="right-section col-md-2 mt-4">
                <div class="nav d-flex justify-content-end gap-4">
                    <button id="menu-btn" class="btn p-0">
                        <span class="material-icons-sharp">menu</span>
                    </button>
                </div>
                <!-- End of Nav -->
            </div>
        </div>
    </div>

    <script src="../assets/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/index.js"></script>
    <script src="../assets/js/attendance.js"></script>
</body>
</html>

<?php
// Helper function to get ordinal suffix (1st, 2nd, 3rd, etc.)
function getOrdinalSuffix($number) {
    if ($number % 100 >= 11 && $number % 100 <= 13) {
        return 'th';
    }
    switch ($number % 10) {
        case 1:  return 'st';
        case 2:  return 'nd';
        case 3:  return 'rd';
        default: return 'th';
    }
}
?>
<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in and is a student
checkAuth();
$user = getCurrentUser($pdo);
if ($user['user_type'] !== 'student') {
    header("Location: ../login.php");
    exit();
}

try {
    // Get student's semester and section
    $stmt = $pdo->prepare("SELECT semester, section FROM students WHERE user_id = ?");
    $stmt->execute([$user['user_id']]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        throw new Exception("Student information not found. Please complete your profile.");
    }

    // Get notices for student's semester/section
    $stmt = $pdo->prepare("SELECT * FROM notices 
                          WHERE (semester = ? OR semester IS NULL OR semester = '') 
                          AND (section = ? OR section IS NULL OR section = '')
                          ORDER BY created_at DESC");
    $stmt->execute([$student['semester'], $student['section']]);
    $notices = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notices | PU</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link href="../assets/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/notice.css">
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar Section -->
            <aside class="col-md-2">
                <div class="toggle d-flex justify-content-between align-items-center mt-3">
                    <div class="logo d-flex align-items-center gap-2">
                        <img src="../assets/image/Logo_of_Premier_University_(PU).png" 
                             class="img-fluid" width="64" height="64" 
                             alt="Premier University Logo">
                        <h2 class="m-0">PU<span class="danger">C</span></h2>
                    </div>
                    <div class="close" id="close-btn">
                        <span class="material-icons-sharp">close</span>
                    </div>
                </div>

                <div class="sidebar bg-white shadow rounded-3 p-3 mt-4 h-88vh position-relative">
                    <a href="../index.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">dashboard</span>
                        <h3 class="m-0 ms-2">Home</h3>
                    </a>
                    <a href="contest.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">insights</span>
                        <h3 class="m-0 ms-2">Contest</h3>
                    </a>
                    <a href="attendance.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">calendar_today</span>
                        <h3>Attendance</h3>
                    </a>
                    <a href="result.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">inventory</span>
                        <h3 class="m-0 ms-2">Result</h3>
                    </a>
                    <a href="notice.php" class="active d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">mail_outline</span>
                        <h3>Notice</h3>
                    </a>
                    <a href="profile.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">settings</span>
                        <h3 class="m-0 ms-2">Edit Profile</h3>
                    </a>
                    <a href="../logout.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded position-absolute bottom-0 start-0 w-100">
                        <span class="material-icons-sharp">logout</span>
                        <h3 class="m-0 ms-2">Logout</h3>
                    </a>
                </div>
            </aside>
            <!-- End of Sidebar Section -->

            <!-- Main Content -->
            <main class="col-md-10">
                <div class="notice-container">
                    <div class="notice-header">
                        <h1 class="fw-bold fs-3 mt-4 d-flex align-items-center">
                            <span class="material-icons-sharp mr-2">mail_outline</span>
                            Department Notices
                        </h1>
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Department Notices -->
                    <div class="notice-cards">
                        <?php if(empty($notices)): ?>
                            <div class="alert alert-info">No notices available for your semester and section.</div>
                        <?php else: ?>
                            <?php foreach($notices as $notice): ?>
                            <div class="notice-card">
                                <div class="notice-card-header">
                                    <h3>
                                        <span class="material-icons-sharp">campaign</span>
                                        <?= htmlspecialchars($notice['title']) ?>
                                    </h3>
                                    <?php if($notice['priority'] === 'urgent'): ?>
                                        <span class="badge bg-danger">URGENT</span>
                                    <?php elseif($notice['priority'] === 'important'): ?>
                                        <span class="badge bg-warning text-dark">IMPORTANT</span>
                                    <?php endif; ?>
                                </div>
                                <div class="notice-meta">
                                    <span>Published: <?= date('j F Y, h:i A', strtotime($notice['created_at'])) ?></span>
                                    <?php if($notice['semester']): ?>
                                    <span>For: <?= htmlspecialchars($notice['semester']) ?> Semester</span>
                                    <?php endif; ?>
                                    <?php if($notice['section']): ?>
                                    <span>Section <?= htmlspecialchars($notice['section']) ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="notice-content">
                                    <p><?= nl2br(htmlspecialchars($notice['content'])) ?></p>
                                </div>
                                <?php if($notice['pdf_path']): ?>
                                <div class="notice-attachment">
                                    <span class="material-icons-sharp">attach_file</span>
                                    <a href="../uploads/<?= htmlspecialchars($notice['pdf_path']) ?>" 
                                       target="_blank" rel="noopener noreferrer" 
                                       class="text-decoration-none">
                                        Download Attachment (<?= strtoupper(pathinfo($notice['pdf_path'], PATHINFO_EXTENSION)) ?>)
                                    </a>
                                    <span class="file-size">
                                        <?php 
                                        $filePath = '../uploads/' . $notice['pdf_path'];
                                        if(file_exists($filePath)) {
                                            $size = filesize($filePath);
                                            if($size < 1024) {
                                                echo $size . ' bytes';
                                            } elseif($size < 1048576) {
                                                echo round($size/1024, 1) . ' KB';
                                            } else {
                                                echo round($size/1048576, 1) . ' MB';
                                            }
                                        }
                                        ?>
                                    </span>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
            <!-- End of Main Content -->
            <div class="right-section col-md-2 mt-4">
                <div class="nav d-flex justify-content-end gap-4">
                    <button id="menu-btn" class="btn p-0">
                        <span class="material-icons-sharp">menu</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/bootstrap/bootstrap.bundle.min.js"></script>
    <script>
                // Sidebar toggle for mobile view
                const sideMenu = document.querySelector('aside');
        const menuBtn = document.getElementById('menu-btn');
        const closeBtn = document.getElementById('close-btn');

        menuBtn.addEventListener('click', () => {
            sideMenu.style.display = 'block';
            sideMenu.style.position = 'fixed';
            sideMenu.style.zIndex = '1000';
        });

        closeBtn.addEventListener('click', () => {
            sideMenu.style.display = 'none';
        });

        // Highlight current page in sidebar
        document.addEventListener('DOMContentLoaded', function() {
            const currentPage = window.location.pathname.split('/').pop();
            const links = document.querySelectorAll('.sidebar a');
            
            links.forEach(link => {
                if(link.getAttribute('href').includes(currentPage)) {
                    link.classList.add('active');
                }
            });
        });
    </script>
</body>
</html>
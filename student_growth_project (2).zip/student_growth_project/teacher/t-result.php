<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in and is a teacher
checkAuth();
$user = getCurrentUser($pdo);
if ($user['user_type'] !== 'teacher') {
    header("Location: ../login.php");
    exit();
}

// Function to calculate grade from marks
function calculateGrade($marks) {
    if ($marks >= 90) return 'A+';
    if ($marks >= 85) return 'A';
    if ($marks >= 80) return 'A-';
    if ($marks >= 75) return 'B+';
    if ($marks >= 70) return 'B';
    if ($marks >= 65) return 'B-';
    if ($marks >= 60) return 'C+';
    if ($marks >= 55) return 'C';
    if ($marks >= 50) return 'D';
    return 'F';
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['save_grades'])) {
        // Process grade submission
        $course_code = $_POST['course_code'];
        $semester = $_POST['semester'];
        $section = $_POST['section'];
        $student_grades = $_POST['student_grades'];
        
        try {
            $pdo->beginTransaction();
            
            foreach ($student_grades as $student_id => $grades) {
                $stmt = $pdo->prepare("
                    INSERT INTO results (student_id, course_code, semester, section, attendance, midterm, final, total, grade, teacher_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                    attendance = VALUES(attendance),
                    midterm = VALUES(midterm),
                    final = VALUES(final),
                    total = VALUES(total),
                    grade = VALUES(grade),
                    updated_at = NOW()
                ");
                $total = $grades['attendance'] + $grades['midterm'] + $grades['final'];
                $grade = calculateGrade($total);
                $stmt->execute([
                    $student_id,
                    $course_code,
                    $semester,
                    $section,
                    $grades['attendance'],
                    $grades['midterm'],
                    $grades['final'],
                    $total,
                    $grade,
                    $user['user_id']
                ]);
            }
            
            $pdo->commit();
            $_SESSION['success_message'] = "Grades saved successfully!";
        } catch (PDOException $e) {
            $pdo->rollBack();
            $_SESSION['error_message'] = "Error saving grades: " . $e->getMessage();
        }
        
        header("Location: t-result.php?tab=grade-entry");
        exit();
    }
    
    if (isset($_POST['publish_results'])) {
        $course_code = $_POST['course_code'];
        $semester = $_POST['semester'];
        $section = $_POST['section'];
        
        try {
            $stmt = $pdo->prepare("UPDATE results SET published = 1 WHERE course_code = ? AND semester = ? AND section = ? AND teacher_id = ?");
            $stmt->execute([$course_code, $semester, $section, $user['user_id']]);
            $_SESSION['success_message'] = "Results published successfully!";
        } catch (PDOException $e) {
            $_SESSION['error_message'] = "Error publishing results: " . $e->getMessage();
        }
        
        header("Location: t-result.php?tab=publish");
        exit();
    }

    if (isset($_POST['unpublish_results'])) {
        $course_code = $_POST['course_code'];
        $semester = $_POST['semester'];
        $section = $_POST['section'];
        
        try {
            $stmt = $pdo->prepare("UPDATE results SET published = 0 WHERE course_code = ? AND semester = ? AND section = ? AND teacher_id = ?");
            $stmt->execute([$course_code, $semester, $section, $user['user_id']]);
            $_SESSION['success_message'] = "Results unpublished successfully!";
        } catch (PDOException $e) {
            $_SESSION['error_message'] = "Error unpublishing results: " . $e->getMessage();
        }
        
        header("Location: t-result.php?tab=publish");
        exit();
    }
}

// Get current tab
$current_tab = isset($_GET['tab']) ? $_GET['tab'] : 'grade-entry';

// Predefined list of courses for all semesters
$all_courses = [
    '1st' => [
        ['code' => 'ENG101', 'name' => 'English Language-I', 'credit' => 3],
        ['code' => 'MAT101', 'name' => 'Mathematics-I', 'credit' => 3],
        ['code' => 'PHY101', 'name' => 'Physics-I', 'credit' => 3],
        ['code' => 'CHE101', 'name' => 'Chemistry-I', 'credit' => 3],
        ['code' => 'CSE101', 'name' => 'Introduction to Computer Science', 'credit' => 3],
    ],
    '2nd' => [
        ['code' => 'ENG102', 'name' => 'English Language-II', 'credit' => 3],
        ['code' => 'MAT102', 'name' => 'Mathematics-II', 'credit' => 3],
        ['code' => 'PHY102', 'name' => 'Physics-II', 'credit' => 3],
        ['code' => 'CHE102', 'name' => 'Chemistry-II', 'credit' => 3],
        ['code' => 'CSE102', 'name' => 'Computer Programming', 'credit' => 3],
    ],
    '3rd' => [
        ['code' => 'CSE201', 'name' => 'Data Structures', 'credit' => 3],
        ['code' => 'CSE202', 'name' => 'Discrete Mathematics', 'credit' => 3],
        ['code' => 'CSE203', 'name' => 'Digital Logic Design', 'credit' => 3],
        ['code' => 'EEE201', 'name' => 'Electrical Circuits', 'credit' => 3],
        ['code' => 'MAT201', 'name' => 'Mathematics-III', 'credit' => 3],
    ],
    '4th' => [
        ['code' => 'CSE204', 'name' => 'Algorithms', 'credit' => 3],
        ['code' => 'CSE205', 'name' => 'Computer Architecture', 'credit' => 3],
        ['code' => 'CSE206', 'name' => 'Database Systems', 'credit' => 3],
        ['code' => 'EEE202', 'name' => 'Electronics', 'credit' => 3],
        ['code' => 'STA201', 'name' => 'Statistics', 'credit' => 3],
    ],
    '5th' => [
        ['code' => 'CSE301', 'name' => 'Operating Systems', 'credit' => 3],
        ['code' => 'CSE302', 'name' => 'Computer Networks', 'credit' => 3],
        ['code' => 'CSE303', 'name' => 'Software Engineering', 'credit' => 3],
        ['code' => 'CSE304', 'name' => 'Theory of Computation', 'credit' => 3],
        ['code' => 'CSE305', 'name' => 'Web Programming', 'credit' => 3],
    ],
    '6th' => [
        ['code' => 'CSE306', 'name' => 'Artificial Intelligence', 'credit' => 3],
        ['code' => 'CSE307', 'name' => 'Compiler Design', 'credit' => 3],
        ['code' => 'CSE308', 'name' => 'Data Communication', 'credit' => 3],
        ['code' => 'CSE309', 'name' => 'Microprocessors', 'credit' => 3],
        ['code' => 'CSE310', 'name' => 'Computer Graphics', 'credit' => 3],
    ],
    '7th' => [
        ['code' => 'CSE401', 'name' => 'Machine Learning', 'credit' => 3],
        ['code' => 'CSE402', 'name' => 'Distributed Systems', 'credit' => 3],
        ['code' => 'CSE403', 'name' => 'Network Security', 'credit' => 3],
        ['code' => 'CSE404', 'name' => 'Cloud Computing', 'credit' => 3],
        ['code' => 'CSE405', 'name' => 'Big Data Analytics', 'credit' => 3],
    ],
    '8th' => [
        ['code' => 'CSE406', 'name' => 'Internet of Things', 'credit' => 3],
        ['code' => 'CSE407', 'name' => 'Advanced Algorithms', 'credit' => 3],
        ['code' => 'CSE408', 'name' => 'Blockchain Technology', 'credit' => 3],
        ['code' => 'CSE409', 'name' => 'Natural Language Processing', 'credit' => 3],
        ['code' => 'CSE410', 'name' => 'Project/Thesis', 'credit' => 6],
    ]
];

// Get students for grade entry
$grade_entry_data = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['select_course'])) {
    $course_code = $_POST['course_code'];
    $semester = $_POST['semester'];
    $section = $_POST['section'];
    
    // Find the selected course
    $selected_course = null;
    foreach ($all_courses[$semester] as $course) {
        if ($course['code'] === $course_code) {
            $selected_course = $course;
            break;
        }
    }
    
    if ($selected_course) {
        $grade_entry_data['course'] = [
            'code' => $selected_course['code'],
            'name' => $selected_course['name'],
            'credit' => $selected_course['credit'],
            'semester' => $semester,
            'section' => $section
        ];
        
        // Get enrolled students with proper error handling
        try {
            // First check if there are enrollments for this course
            $enrollment_check = $pdo->prepare("
                SELECT COUNT(*) 
                FROM enrollments 
                WHERE course_code = ? AND semester = ? AND section = ?
            ");
            $enrollment_check->execute([$course_code, $semester, $section]);
            $has_enrollments = $enrollment_check->fetchColumn() > 0;
            
            if ($has_enrollments) {
                // Get all enrolled students with their existing grades if any
                $stmt = $pdo->prepare("
                    SELECT 
                        u.user_id, 
                        u.last_name,
                        u.last_name,
                        r.attendance, 
                        r.midterm, 
                        r.final, 
                        r.total, 
                        r.grade,
                        r.published
                    FROM users u
                    JOIN enrollments e ON u.user_id = e.student_id
                    LEFT JOIN results r ON 
                        u.user_id = r.student_id AND 
                        e.course_code = r.course_code AND 
                        e.semester = r.semester AND 
                        e.section = r.section
                    WHERE 
                        e.course_code = ? AND 
                        e.semester = ? AND 
                        e.section = ? AND
                        u.user_type = 'student'
                    ORDER BY u.last_name, u.last_name
                ");
                $stmt->execute([$course_code, $semester, $section]);
                $grade_entry_data['students'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            } else {
                // No enrollments found
                $grade_entry_data['students'] = [];
                $_SESSION['error_message'] = "No students are enrolled in this course section.";
            }
        } catch (PDOException $e) {
            $_SESSION['error_message'] = "Error fetching students: " . $e->getMessage();
            $grade_entry_data['students'] = [];
        }
    }
}

// Get courses for publish tab (only courses with grades entered by this teacher)
$publish_courses = [];
try {
    $stmt = $pdo->prepare("
        SELECT course_code, semester, section, 
               COUNT(*) AS graded_students,
               SUM(published) AS published_count
        FROM results
        WHERE teacher_id = ?
        GROUP BY course_code, semester, section
        ORDER BY semester, course_code
    ");
    $stmt->execute([$user['user_id']]);
    $publish_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Error fetching publishable courses: " . $e->getMessage();
}

function ordinalSuffix($semester) {
    return $semester;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link href="../assets/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/t-result.css">
    <title>Result Management | PU</title>
    <style>
        .grade-table {
            width: 100%;
            margin-bottom: 1rem;
            color: #212529;
        }
        .grade-table th, .grade-table td {
            padding: 0.75rem;
            vertical-align: middle;
            border-top: 1px solid #dee2e6;
        }
        .grade-table thead th {
            vertical-align: bottom;
            border-bottom: 2px solid #dee2e6;
        }
        .grade-table tbody + tbody {
            border-top: 2px solid #dee2e6;
        }
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
        .tab-controls {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        .tab-btn {
            padding: 10px 20px;
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            cursor: pointer;
        }
        .tab-btn.active {
            background: #0d6efd;
            color: white;
            border-color: #0d6efd;
        }
        .student-card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .filter-controls {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }
        .filter-control {
            flex: 1;
        }
        .badge {
            display: inline-block;
            padding: 0.35em 0.65em;
            font-size: 0.75em;
            font-weight: 700;
            line-height: 1;
            color: #fff;
            text-align: center;
            white-space: nowrap;
            vertical-align: baseline;
            border-radius: 0.25rem;
        }
        .bg-success {
            background-color: #198754!important;
        }
        .bg-warning {
            background-color: #ffc107!important;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar Section -->
            <aside class="col-md-2">
                <div class="toggle d-flex justify-content-between align-items-center mt-3">
                    <div class="logo d-flex align-items-center gap-2">
                        <img src="../assets/image/Logo_of_Premier_University_(PU).png" class="img-fluid" width="64" height="64">
                        <h2 class="m-0">PU<span class="danger">C</span></h2>
                    </div>
                    <div class="close" id="close-btn">
                        <span class="material-icons-sharp">close</span>
                    </div>
                </div>

                <div class="sidebar bg-white shadow rounded-3 p-3 mt-4 h-88vh position-relative">
                    <a href="teacher_dashboard.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">dashboard</span>
                        <h3 class="m-0 ms-2">Home</h3>
                    </a>
                    <a href="t-contest.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">insights</span>
                        <h3 class="m-0 ms-2">Contest</h3>
                    </a>
                    <a href="t-attendance.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">calendar_today</span>
                        <h3>Attendance</h3>
                    </a>
                    <a href="t-result.php" class="active d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">grading</span>
                        <h3 class="m-0 ms-2">Results</h3>
                    </a>
                    <a href="t-notice.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">mail_outline</span>
                        <h3>Notice</h3>
                    </a>
                    <a href="t-profile.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">settings</span>
                        <h3 class="m-0 ms-2">Profile</h3>
                    </a>
                    <a href="../logout.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded position-absolute bottom-0 start-0 w-100">
                        <span class="material-icons-sharp">logout</span>
                        <h3 class="m-0 ms-2">Logout</h3>
                    </a>
                </div>
            </aside>
            <!-- End of Sidebar Section -->

            <!-- Main Content -->
            <main class="col-md-10">
                <div class="result-management-container">
                    <h1 class="fw-bold fs-3 mt-4">Result Management</h1>
                    
                    <?php if (isset($_SESSION['error_message'])): ?>
                        <div class="alert alert-danger"><?= $_SESSION['error_message'] ?></div>
                        <?php unset($_SESSION['error_message']); ?>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['success_message'])): ?>
                        <div class="alert alert-success"><?= $_SESSION['success_message'] ?></div>
                        <?php unset($_SESSION['success_message']); ?>
                    <?php endif; ?>
                    
                    <!-- Tab Controls -->
                    <div class="tab-controls">
                        <button class="tab-btn <?= $current_tab === 'grade-entry' ? 'active' : '' ?>" data-tab="grade-entry">Grade Entry</button>
                        <button class="tab-btn <?= $current_tab === 'publish' ? 'active' : '' ?>" data-tab="publish">Publish Results</button>
                    </div>
                    
                    <!-- Grade Entry Tab -->
                    <div class="tab-content <?= $current_tab === 'grade-entry' ? 'active' : '' ?>" id="grade-entry-tab">
                        <?php if (empty($grade_entry_data)): ?>
                            <form method="post" class="course-selection-form">
                                <h3>Select Course to Enter Grades</h3>
                                
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="semester">Semester</label>
                                            <select class="form-control" id="semester" name="semester" required>
                                                <option value="">Select Semester</option>
                                                <?php foreach (array_keys($all_courses) as $semester): ?>
                                                    <option value="<?= $semester ?>"><?= $semester ?> Semester</option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="course_code">Course</label>
                                            <select class="form-control" id="course_code" name="course_code" required disabled>
                                                <option value="">Select Course</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="section">Section</label>
                                            <select class="form-control" id="section" name="section" required>
                                                <option value="">Select Section</option>
                                                <option value="A">Section A</option>
                                                <option value="B">Section B</option>
                                                <option value="C">Section C</option>
                                                <option value="D">Section D</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <button type="submit" name="select_course" class="btn btn-primary mt-3">
                                    <span class="material-icons-sharp">search</span>
                                    Select Course
                                </button>
                            </form>
                        <?php else: ?>
                            <form method="post">
                                <input type="hidden" name="course_code" value="<?= $grade_entry_data['course']['code'] ?>">
                                <input type="hidden" name="semester" value="<?= $grade_entry_data['course']['semester'] ?>">
                                <input type="hidden" name="section" value="<?= $grade_entry_data['course']['section'] ?>">
                                
                                <h3><?= htmlspecialchars($grade_entry_data['course']['code']) ?> - <?= htmlspecialchars($grade_entry_data['course']['name']) ?> (<?= $grade_entry_data['course']['semester'] ?> Semester - Section <?= $grade_entry_data['course']['section'] ?>)</h3>
                                <p><strong>Credit Hours:</strong> <?= $grade_entry_data['course']['credit'] ?></p>
                                
                                <?php if (!empty($grade_entry_data['students'])): ?>
                                    <div class="table-responsive">
                                        <table class="grade-table table table-bordered table-hover">
                                            <thead class="table-dark">
                                                <tr>
                                                    <th>#</th>
                                                    <th>Student ID</th>
                                                    <th>Student Name</th>
                                                    <th>Attendance (20)</th>
                                                    <th>Midterm (30)</th>
                                                    <th>Final (50)</th>
                                                    <th>Total (100)</th>
                                                    <th>Grade</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($grade_entry_data['students'] as $index => $student): ?>
                                                    <tr>
                                                        <td><?= $index + 1 ?></td>
                                                        <td><?= htmlspecialchars($student['user_id']) ?></td>
                                                        <td><?= htmlspecialchars($student['full_name'] ?? $student['last_name']) ?></td>
                                                        <td>
                                                            <input type="number" 
                                                                   name="student_grades[<?= $student['user_id'] ?>][attendance]" 
                                                                   value="<?= $student['attendance'] ?? '' ?>" 
                                                                   min="0" max="20" 
                                                                   class="form-control attendance-input" 
                                                                   required>
                                                        </td>
                                                        <td>
                                                            <input type="number" 
                                                                   name="student_grades[<?= $student['user_id'] ?>][midterm]" 
                                                                   value="<?= $student['midterm'] ?? '' ?>" 
                                                                   min="0" max="30" 
                                                                   class="form-control midterm-input" 
                                                                   required>
                                                        </td>
                                                        <td>
                                                            <input type="number" 
                                                                   name="student_grades[<?= $student['user_id'] ?>][final]" 
                                                                   value="<?= $student['final'] ?? '' ?>" 
                                                                   min="0" max="50" 
                                                                   class="form-control final-input" 
                                                                   required>
                                                        </td>
                                                        <td class="total-cell">
                                                            <?= ($student['attendance'] ?? 0) + ($student['midterm'] ?? 0) + ($student['final'] ?? 0) ?>
                                                        </td>
                                                        <td>
                                                            <select name="student_grades[<?= $student['user_id'] ?>][grade]" 
                                                                    class="form-select grade-select" required>
                                                                <option value="A+" <?= ($student['grade'] ?? '') === 'A+' ? 'selected' : '' ?>>A+ (90-100)</option>
                                                                <option value="A" <?= ($student['grade'] ?? '') === 'A' ? 'selected' : '' ?>>A (85-89)</option>
                                                                <option value="A-" <?= ($student['grade'] ?? '') === 'A-' ? 'selected' : '' ?>>A- (80-84)</option>
                                                                <option value="B+" <?= ($student['grade'] ?? '') === 'B+' ? 'selected' : '' ?>>B+ (75-79)</option>
                                                                <option value="B" <?= ($student['grade'] ?? '') === 'B' ? 'selected' : '' ?>>B (70-74)</option>
                                                                <option value="B-" <?= ($student['grade'] ?? '') === 'B-' ? 'selected' : '' ?>>B- (65-69)</option>
                                                                <option value="C+" <?= ($student['grade'] ?? '') === 'C+' ? 'selected' : '' ?>>C+ (60-64)</option>
                                                                <option value="C" <?= ($student['grade'] ?? '') === 'C' ? 'selected' : '' ?>>C (55-59)</option>
                                                                <option value="D" <?= ($student['grade'] ?? '') === 'D' ? 'selected' : '' ?>>D (50-54)</option>
                                                                <option value="F" <?= empty($student['grade']) || ($student['grade'] ?? '') === 'F' ? 'selected' : '' ?>>F (Below 50)</option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <?= ($student['published'] ?? 0) ? 
                                                                '<span class="badge bg-success">Published</span>' : 
                                                                '<span class="badge bg-warning text-dark">Draft</span>' ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                    <div class="action-buttons mt-3 d-flex gap-2">
                                        <button type="submit" name="save_grades" class="btn btn-primary">
                                            <span class="material-icons-sharp">save</span>
                                            Save Grades
                                        </button>
                                        <button type="submit" name="publish_results" class="btn btn-success">
                                            <span class="material-icons-sharp">publish</span>
                                            Save & Publish
                                        </button>
                                        <a href="t-result.php?tab=grade-entry" class="btn btn-danger">
                                            <span class="material-icons-sharp">cancel</span>
                                            Cancel
                                        </a>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-info">
                                        <h4>No Students Found</h4>
                                        <p>There are no students enrolled in <?= htmlspecialchars($grade_entry_data['course']['code']) ?> - 
                                           <?= htmlspecialchars($grade_entry_data['course']['name']) ?> 
                                           (<?= $grade_entry_data['course']['semester'] ?> Semester - Section <?= $grade_entry_data['course']['section'] ?>).</p>
                                        <p>Please check with the administration if you believe this is incorrect.</p>
                                    </div>
                                    <a href="t-result.php?tab=grade-entry" class="btn btn-primary">
                                        <span class="material-icons-sharp">arrow_back</span>
                                        Back to Course Selection
                                    </a>
                                <?php endif; ?>
                            </form>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Publish Results Tab -->
                    <div class="tab-content <?= $current_tab === 'publish' ? 'active' : '' ?>" id="publish-tab">
                        <div class="filter-controls">
                            <div class="form-group filter-control">
                                <label for="publish-semester">Semester</label>
                                <select class="form-control" id="publish-semester">
                                    <option value="all">All Semesters</option>
                                    <?php 
                                    // Get unique semesters from teacher's publishable courses
                                    $publish_semesters = array_unique(array_column($publish_courses, 'semester'));
                                    sort($publish_semesters);
                                    foreach ($publish_semesters as $semester): ?>
                                        <option value="<?= $semester ?>"><?= $semester ?> Semester</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group filter-control">
                                <label for="publish-section">Section</label>
                                <select class="form-control" id="publish-section">
                                    <option value="all">All Sections</option>
                                    <?php 
                                    // Get unique sections from teacher's publishable courses
                                    $publish_sections = array_unique(array_column($publish_courses, 'section'));
                                    sort($publish_sections);
                                    foreach ($publish_sections as $section): ?>
                                        <option value="<?= $section ?>">Section <?= $section ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="publish-list">
                            <?php if (empty($publish_courses)): ?>
                                <div class="alert alert-info">No courses with grades available for publishing.</div>
                            <?php else: ?>
                                <?php foreach ($publish_courses as $course): ?>
                                    <div class="student-card" data-semester="<?= $course['semester'] ?>" data-section="<?= $course['section'] ?>">
                                        <h4><?= htmlspecialchars($course['course_code']) ?> (<?= $course['semester'] ?> Semester - Section <?= $course['section'] ?>)</h4>
                                        <p>
                                            <strong>Status:</strong> 
                                            <?= $course['published_count'] > 0 ? 'Published' : 'Draft' ?> | 
                                            <strong>Graded Students:</strong> <?= $course['graded_students'] ?>
                                        </p>
                                        <div class="action-buttons">
                                            <form method="post" style="display: inline;">
                                                <input type="hidden" name="course_code" value="<?= $course['course_code'] ?>">
                                                <input type="hidden" name="semester" value="<?= $course['semester'] ?>">
                                                <input type="hidden" name="section" value="<?= $course['section'] ?>">
                                                <?php if ($course['published_count'] > 0): ?>
                                                    <button type="submit" name="unpublish_results" class="btn btn-danger">
                                                        <span class="material-icons-sharp">unpublished</span>
                                                        Unpublish
                                                    </button>
                                                    <a href="result.php?course_code=<?= $course['course_code'] ?>&semester=<?= $course['semester'] ?>&section=<?= $course['section'] ?>" target="_blank" class="btn btn-primary">
                                                        <span class="material-icons-sharp">preview</span>
                                                        View Published
                                                    </a>
                                                <?php else: ?>
                                                    <button type="submit" name="publish_results" class="btn btn-success">
                                                        <span class="material-icons-sharp">publish</span>
                                                        Publish Results
                                                    </button>
                                                    <a href="t-result.php?tab=grade-entry&course_code=<?= $course['course_code'] ?>&semester=<?= $course['semester'] ?>&section=<?= $course['section'] ?>" class="btn btn-primary">
                                                        <span class="material-icons-sharp">edit</span>
                                                        Edit Grades
                                                    </a>
                                                <?php endif; ?>
                                            </form>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </main>
            <!-- End of Main Content -->

            <div class="right-section col-md-2 mt-4">
                <div class="nav d-flex justify-content-end gap-4">
                    <button id="menu-btn" class="btn p-0">
                        <span class="material-icons-sharp">menu</span>
                    </button>
                </div>
                <!-- End of Nav -->
            </div>
        </div>
    </div>

    <script src="../assets/bootstrap/bootstrap.bundle.min.js"></script>
    <script>
                // Sidebar toggle for mobile view
                const sideMenu = document.querySelector('aside');
        const menuBtn = document.getElementById('menu-btn');
        const closeBtn = document.getElementById('close-btn');

        menuBtn.addEventListener('click', () => {
            sideMenu.style.display = 'block';
            sideMenu.style.position = 'fixed';
            sideMenu.style.zIndex = '1000';
        });

        closeBtn.addEventListener('click', () => {
            sideMenu.style.display = 'none';
        });
        // Tab functionality
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all tabs
                document.querySelectorAll('.tab-btn').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                
                // Add active class to clicked tab
                this.classList.add('active');
                const tabId = this.getAttribute('data-tab');
                document.getElementById(tabId + '-tab').classList.add('active');
                
                // Update URL
                const url = new URL(window.location);
                url.searchParams.set('tab', tabId);
                window.history.pushState({}, '', url);
            });
        });
        
        // Filter publish list by semester and section
        function filterPublishList() {
            const semester = document.getElementById('publish-semester').value;
            const section = document.getElementById('publish-section').value;
            
            document.querySelectorAll('.publish-list .student-card').forEach(card => {
                const cardSemester = card.getAttribute('data-semester');
                const cardSection = card.getAttribute('data-section');
                
                const semesterMatch = semester === 'all' || cardSemester === semester;
                const sectionMatch = section === 'all' || cardSection === section;
                
                if (semesterMatch && sectionMatch) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }
        
        // Initialize filters
        document.getElementById('publish-semester').addEventListener('change', filterPublishList);
        document.getElementById('publish-section').addEventListener('change', filterPublishList);
        
        // Calculate total and grade when input values change
        document.addEventListener('input', function(e) {
            if (e.target.classList.contains('attendance-input') || 
                e.target.classList.contains('midterm-input') || 
                e.target.classList.contains('final-input')) {
                
                const row = e.target.closest('tr');
                const attendance = parseFloat(row.querySelector('.attendance-input').value) || 0;
                const midterm = parseFloat(row.querySelector('.midterm-input').value) || 0;
                const final = parseFloat(row.querySelector('.final-input').value) || 0;
                const total = attendance + midterm + final;
                
                row.querySelector('.total-cell').textContent = total;
                
                // Auto-select grade based on total
                const gradeSelect = row.querySelector('.grade-select');
                let grade = 'F';
                if (total >= 90) grade = 'A+';
                else if (total >= 85) grade = 'A';
                else if (total >= 80) grade = 'A-';
                else if (total >= 75) grade = 'B+';
                else if (total >= 70) grade = 'B';
                else if (total >= 65) grade = 'B-';
                else if (total >= 60) grade = 'C+';
                else if (total >= 55) grade = 'C';
                else if (total >= 50) grade = 'D';
                
                gradeSelect.value = grade;
            }
        });
        
        // Dynamic course selection based on semester
        document.getElementById('semester').addEventListener('change', function() {
            const semester = this.value;
            const courseSelect = document.getElementById('course_code');
            
            courseSelect.innerHTML = '<option value="">Select Course</option>';
            
            if (semester) {
                courseSelect.disabled = false;
                
                // Get courses for selected semester from predefined list
                const courses = <?= json_encode($all_courses) ?>;
                
                if (courses[semester]) {
                    courses[semester].forEach(course => {
                        const option = document.createElement('option');
                        option.value = course.code;
                        option.textContent = `${course.code} - ${course.name} (${course.credit} Credits)`;
                        courseSelect.appendChild(option);
                    });
                }
            } else {
                courseSelect.disabled = true;
            }
        });
        
        // Initialize filters on page load
        document.addEventListener('DOMContentLoaded', function() {
            filterPublishList();
            
            // Set active tab from URL
            const urlParams = new URLSearchParams(window.location.search);
            const tab = urlParams.get('tab');
            if (tab) {
                document.querySelector(`.tab-btn[data-tab="${tab}"]`).click();
            }
        });
    </script>
</body>
</html>
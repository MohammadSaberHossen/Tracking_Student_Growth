<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in and is a teacher
checkAuth();
$user = getCurrentUser($pdo);
if ($user['user_type'] !== 'teacher') {
    header("Location: ../../login.php");
    exit();
}

// Get teacher details
$stmt = $pdo->prepare("SELECT t.*, u.* FROM teachers t JOIN users u ON t.user_id = u.user_id WHERE t.user_id = ?");
$stmt->execute([$user['user_id']]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $position = $_POST['position'];
    $department = $_POST['department'];
    
    // Update user table
    $stmt = $pdo->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, gender = ?, dob = ?, department = ? WHERE user_id = ?");
    $stmt->execute([$firstName, $lastName, $email, $phone, $gender, $dob, $department, $user['user_id']]);
    
    // Update teacher table
    $stmt = $pdo->prepare("UPDATE teachers SET position = ?, department = ? WHERE user_id = ?");
    $stmt->execute([$position, $department, $user['user_id']]);
    
    // Handle password change if provided
    if (!empty($_POST['current_password']) && !empty($_POST['new_password'])) {
        if (password_verify($_POST['current_password'], $teacher['password'])) {
            $newPassword = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
            $stmt->execute([$newPassword, $user['user_id']]);
        } else {
            $error = "Current password is incorrect";
        }
    }
    
    // Handle profile image upload
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/profile_images/';
        
        // Create directory if it doesn't exist
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        // Validate file type and size
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 2 * 1024 * 1024; // 2MB
        
        if (in_array($_FILES['profile_image']['type'], $allowedTypes) && 
            $_FILES['profile_image']['size'] <= $maxSize) {
            
            // Delete old image if exists
            if (!empty($teacher['profile_image']) && file_exists($uploadDir . $teacher['profile_image'])) {
                unlink($uploadDir . $teacher['profile_image']);
            }
            
            // Generate unique filename
            $extension = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
            $imageName = uniqid() . '.' . $extension;
            $targetPath = $uploadDir . $imageName;
            
            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $targetPath)) {
                $stmt = $pdo->prepare("UPDATE users SET profile_image = ? WHERE user_id = ?");
                $stmt->execute([$imageName, $user['user_id']]);
                
                // Update the displayed image immediately
                $teacher['profile_image'] = $imageName;
            } else {
                $error = "Failed to upload profile image";
            }
        } else {
            $error = "Invalid file type or file too large (max 2MB)";
        }
    }
    
    // Refresh teacher data after update
    $stmt = $pdo->prepare("SELECT t.*, u.* FROM teachers t JOIN users u ON t.user_id = u.user_id WHERE t.user_id = ?");
    $stmt->execute([$user['user_id']]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // No redirect to show success/error messages
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link href="../assets/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/profile.css">
    <title>Edit Profile | PU</title>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar Section -->
            <aside class="col-md-2">
                <div class="toggle d-flex justify-content-between align-items-center mt-3">
                    <div class="logo d-flex align-items-center gap-2">
                        <img src="../assets/image/Logo_of_Premier_University_(PU).png" class="img-fluid" width="64" height="64">
                        <h2 class="m-0">PU<span class="danger">C</span></h2>
                    </div>
                    <div class="close" id="close-btn">
                        <span class="material-icons-sharp">close</span>
                    </div>
                </div>

                <div class="sidebar bg-white shadow rounded-3 p-3 mt-4 h-88vh position-relative">
                    <a href="teacher_dashboard.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">dashboard</span>
                        <h3 class="m-0 ms-2">Home</h3>
                    </a>
                    <a href="t-contest.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">insights</span>
                        <h3 class="m-0 ms-2">Contest</h3>
                    </a>
                    <a href="t-attendance.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">calendar_today</span>
                        <h3>Attendance</h3>
                    </a>
                    <a href="t-result.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">grading</span>
                        <h3 class="m-0 ms-2">Results</h3>
                    </a>
                    <a href="t-notice.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">mail_outline</span>
                        <h3>Notice</h3>
                    </a>
                    <a href="t-profile.php" class="active d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">settings</span>
                        <h3 class="m-0 ms-2">Profile</h3>
                    </a>
                    <a href="../logout.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded position-absolute bottom-0 start-0 w-100">
                        <span class="material-icons-sharp">logout</span>
                        <h3 class="m-0 ms-2">Logout</h3>
                    </a>
                </div>
            </aside>
            <!-- End of Sidebar Section -->

            <!-- Main Content -->
            <main class="col-md-10">
                <div class="profile-container">
                    <div class="profile-header">
                        <h1 class="fw-bold fs-3 mt-4 d-flex align-items-center">
                            <span class="material-icons-sharp mr-2">settings</span>
                            Edit Profile
                        </h1>
                    </div>
                    
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>
                    
                    <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($error)): ?>
                        <div class="alert alert-success">Profile updated successfully!</div>
                    <?php endif; ?>
                    
                    <form method="POST" enctype="multipart/form-data" class="profile-form">
                        <!-- Profile Photo Upload -->
                        <div class="photo-upload">
                            <img src="<?= !empty($teacher['profile_image']) ? '../uploads/profile_images/' . htmlspecialchars($teacher['profile_image']) : '../assets/image/default-profile.jpg' ?>" 
                                 alt="Profile Photo" class="profile-photo" id="profileImagePreview">
                            <label for="profile_image" class="upload-btn">
                                <span class="material-icons-sharp">photo_camera</span>
                                Upload Photo
                            </label>
                            <input type="file" id="profile_image" name="profile_image" accept="image/jpeg, image/png, image/gif" style="display: none;">
                            <small class="d-block text-muted mt-2">Max 2MB (JPEG, PNG, GIF)</small>
                        </div>
                        
                        <!-- Personal Information -->
                        <div class="form-group">
                            <label for="first_name">First Name</label>
                            <input type="text" id="first_name" name="first_name" class="form-control" 
                                   value="<?= htmlspecialchars($teacher['first_name']) ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="last_name">Last Name</label>
                            <input type="text" id="last_name" name="last_name" class="form-control" 
                                   value="<?= htmlspecialchars($teacher['last_name']) ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="teacher_id">Teacher ID</label>
                            <input type="text" id="teacher_id" class="form-control" 
                                   value="<?= htmlspecialchars($teacher['teacher_id']) ?>" readonly>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" class="form-control" 
                                   value="<?= htmlspecialchars($teacher['email']) ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" class="form-control" 
                                   value="<?= htmlspecialchars($teacher['phone']) ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="dob">Date of Birth</label>
                            <input type="date" id="dob" name="dob" class="form-control" 
                                   value="<?= htmlspecialchars($teacher['dob']) ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="gender">Gender</label>
                            <select id="gender" name="gender" class="form-control">
                                <option value="male" <?= $teacher['gender'] == 'male' ? 'selected' : '' ?>>Male</option>
                                <option value="female" <?= $teacher['gender'] == 'female' ? 'selected' : '' ?>>Female</option>
                                <option value="other" <?= $teacher['gender'] == 'other' ? 'selected' : '' ?>>Other</option>
                            </select>
                        </div>
                        
                        <!-- Teacher Information -->
                        <div class="form-group">
                            <label for="position">Position</label>
                            <input type="text" id="position" name="position" class="form-control" 
                                   value="<?= htmlspecialchars($teacher['position']) ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="department">Department</label>
                            <input type="text" id="department" name="department" class="form-control" 
                                   value="<?= htmlspecialchars($teacher['department']) ?>" required>
                        </div>
                        
                        <!-- Password Change -->
                        <div class="form-group full-width">
                            <h3 class="d-flex align-items-center" style="color: var(--color-primary); margin-bottom: 1rem;">
                                <span class="material-icons-sharp mr-2">lock</span>
                                Change Password
                            </h3>
                        </div>
                        
                        <div class="form-group">
                            <label for="current_password">Current Password</label>
                            <input type="password" id="current_password" name="current_password" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label for="new_password">New Password</label>
                            <input type="password" id="new_password" name="new_password" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">Confirm Password</label>
                            <input type="password" id="confirm_password" name="confirm_password" class="form-control">
                        </div>
                        
                        <!-- Form Actions -->
                        <div class="form-actions">
                            <button type="reset" class="btn btn-outline">Cancel</button>
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            </main>
            <!-- End of Main Content -->
            <div class="right-section col-md-2 mt-4">
                <div class="nav d-flex justify-content-end gap-4">
                    <button id="menu-btn" class="btn p-0">
                        <span class="material-icons-sharp">menu</span>
                    </button>
                </div>
                <!-- End of Nav -->
            </div>
        </div>
    </div>

    <script src="../assets/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/index.js"></script>
    <script src="../assets/js/t-profile.js"></script>
</body>
</html>
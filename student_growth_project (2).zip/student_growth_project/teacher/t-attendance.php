<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';
checkAuth();

$user = getCurrentUser($GLOBALS['pdo']);
if ($user['user_type'] !== 'teacher') {
    header("Location: " . ($user['user_type'] === 'student' ? "../index.php" : "../login.php"));
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['student_id'])) {
    $student_id = $_POST['student_id'];
    
    foreach ($_POST['attendance'] as $semester => $data) {
        $total = $data['total'];
        $attended = $data['attended'];
        
        $stmt = $GLOBALS['pdo']->prepare("INSERT INTO attendance (student_id, semester, total_classes, attended_classes) 
                                         VALUES (?, ?, ?, ?)
                                         ON DUPLICATE KEY UPDATE 
                                         total_classes = VALUES(total_classes), 
                                         attended_classes = VALUES(attended_classes)");
        $stmt->execute([$student_id, $semester, $total, $attended]);
    }
    
    $_SESSION['success'] = "Attendance saved successfully!";
    header("Location: t-attendance.php");
    exit();
}

// Get all students for dropdown
$stmt = $GLOBALS['pdo']->prepare("SELECT s.roll_number, u.first_name, u.last_name 
                                 FROM students s JOIN users u ON s.user_id = u.user_id
                                 ORDER BY s.roll_number");
$stmt->execute();
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get attendance data for selected student
$attendance_data = [];
if (isset($_GET['student_id'])) {
    $stmt = $GLOBALS['pdo']->prepare("SELECT semester, total_classes, attended_classes 
                                     FROM attendance WHERE student_id = ?");
    $stmt->execute([$_GET['student_id']]);
    $attendance_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link href="../assets/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/t-attendance.css">
    <title>Attendance Management | PU</title>
</head>

<body>
    <div class="container-fluid">
        <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>
        
        <div class="row">
            <!-- Sidebar Section -->
            <aside class="col-md-2">
                <div class="toggle d-flex justify-content-between align-items-center mt-3">
                    <div class="logo d-flex align-items-center gap-2">
                        <img src="../assets/image/Logo_of_Premier_University_(PU).png" class="img-fluid" width="64" height="64">
                        <h2 class="m-0">PU<span class="danger">C</span></h2>
                    </div>
                    <div class="close" id="close-btn">
                        <span class="material-icons-sharp">close</span>
                    </div>
                </div>

                <div class="sidebar bg-white shadow rounded-3 p-3 mt-4 h-88vh position-relative">
                    <a href="teacher_dashboard.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">dashboard</span>
                        <h3 class="m-0 ms-2">Home</h3>
                    </a>
                    <a href="t-contest.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">insights</span>
                        <h3 class="m-0 ms-2">Contest</h3>
                    </a>
                    <a href="t-attendance.php" class="active d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">calendar_today</span>
                        <h3 class="m-0 ms-2">Attendance</h3>
                    </a>
                    <a href="t-result.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">grading</span>
                        <h3 class="m-0 ms-2">Results</h3>
                    </a>
                    <a href="t-notice.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">mail_outline</span>
                        <h3 class="m-0 ms-2">Notice</h3>
                    </a>
                    <a href="t-profile.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">settings</span>
                        <h3 class="m-0 ms-2">Profile</h3>
                    </a>
                    <a href="../logout.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded position-absolute bottom-0 start-0 w-100">
                        <span class="material-icons-sharp">logout</span>
                        <h3 class="m-0 ms-2">Logout</h3>
                    </a>
                </div>
            </aside>
            <!-- End of Sidebar Section -->

            <!-- Main Content -->
            <main class="col-md-10">
                <div class="attendance-simple-container">
                    <h1 class="fw-bold fs-3 mt-4 d-flex align-items-center">
                        <span class="material-icons-sharp mr-2">calendar_today</span>
                        Semester Attendance Management
                    </h1>
                    
                    <!-- Student Selection -->
                    <form method="get" class="student-select mb-4">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="student-select" class="form-label">Select Student</label>
                                <select class="form-select" id="student-select" name="student_id" onchange="this.form.submit()">
                                    <option value="">Choose a student...</option>
                                    <?php foreach ($students as $student): ?>
                                    <option value="<?php echo $student['roll_number']; ?>" 
                                        <?php echo isset($_GET['student_id']) && $_GET['student_id'] == $student['roll_number'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name'] . ' (' . $student['roll_number'] . ')'); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </form>
                    
                    <?php if (isset($_GET['student_id'])): ?>
                    <form method="post">
                        <input type="hidden" name="student_id" value="<?php echo htmlspecialchars($_GET['student_id']); ?>">
                        
                        <!-- Semester Attendance Cards -->
                        <div class="semester-cards">
                            <?php for ($i = 1; $i <= 8; $i++): 
                                $current = array_filter($attendance_data, function($a) use ($i) { return $a['semester'] == $i; });
                                $current = reset($current);
                                
                                $total = $current['total_classes'] ?? 0;
                                $attended = $current['attended_classes'] ?? 0;
                                $percentage = $total > 0 ? round(($attended/$total)*100) : 0;
                            ?>
                            <div class="semester-card">
                                <div class="semester-header">
                                    <h3><?php echo $i; ?>th Semester</h3>
                                    <div class="total-classes">
                                        <span>Total Classes: </span>
                                        <input type="number" class="form-control" name="attendance[<?php echo $i; ?>][total]" 
                                               value="<?php echo $total; ?>" min="0">
                                    </div>
                                </div>
                                <div class="attendance-control">
                                    <label>Classes Attended:</label>
                                    <input type="number" class="form-control attended-classes" 
                                           name="attendance[<?php echo $i; ?>][attended]" 
                                           value="<?php echo $attended; ?>" min="0">
                                </div>
                                <div class="attendance-percentage">
                                    <div class="percentage-value"><?php echo $percentage; ?>%</div>
                                    <div class="progress">
                                        <div class="progress-bar" 
                                             style="width: <?php echo $percentage; ?>%;
                                                    background-color: <?php 
                                                        if ($percentage < 75) echo 'var(--color-danger)';
                                                        elseif ($percentage < 90) echo 'var(--color-warning)';
                                                        else echo 'var(--color-success)';
                                                    ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endfor; ?>
                        </div>
                        
                        <!-- Save Button -->
                        <div class="save-section mt-4">
                            <button type="submit" class="btn btn-primary" id="save-attendance">
                                <span class="material-icons-sharp">save</span> Save Attendance
                            </button>
                        </div>
                    </form>
                    <?php endif; ?>
                </div>
            </main>
            <!-- End of Main Content -->
            <div class="right-section col-md-2 mt-4">
                <div class="nav d-flex justify-content-end gap-4">
                    <button id="menu-btn" class="btn p-0">
                        <span class="material-icons-sharp">menu</span>
                    </button>
                </div>
                <!-- End of Nav -->
            </div>
        </div>
    </div>

    <script src="../assets/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/index.js"></script>
    <script src="../assets/js/t-attendance.php"></script>
</body>
</html>
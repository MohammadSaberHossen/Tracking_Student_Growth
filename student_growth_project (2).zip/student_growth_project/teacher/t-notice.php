<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check authentication
checkAuth();
$user = getCurrentUser($pdo);
if ($user['user_type'] !== 'teacher') {
    header("Location: ../login.php");
    exit();
}

// Handle actions
$action = $_GET['action'] ?? '';
$noticeId = $_GET['id'] ?? 0;

// Delete notice
if ($action === 'delete' && $noticeId) {
    $stmt = $pdo->prepare("SELECT pdf_path FROM notices WHERE notice_id = ? AND published_by = ?");
    $stmt->execute([$noticeId, $user['user_id']]);
    $notice = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($notice) {
        if ($notice['pdf_path'] && file_exists('../uploads/' . $notice['pdf_path'])) {
            unlink('../uploads/' . $notice['pdf_path']);
        }
        $pdo->prepare("DELETE FROM notices WHERE notice_id = ? AND published_by = ?")->execute([$noticeId, $user['user_id']]);
    }
    header("Location: t-notice.php");
    exit();
}

// Delete PDF only
if ($action === 'delete_pdf' && $noticeId) {
    $stmt = $pdo->prepare("SELECT pdf_path FROM notices WHERE notice_id = ? AND published_by = ?");
    $stmt->execute([$noticeId, $user['user_id']]);
    $notice = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($notice && $notice['pdf_path']) {
        if (file_exists('../uploads/' . $notice['pdf_path'])) {
            unlink('../uploads/' . $notice['pdf_path']);
        }
        $pdo->prepare("UPDATE notices SET pdf_path = NULL WHERE notice_id = ? AND published_by = ?")->execute([$noticeId, $user['user_id']]);
    }
    header("Location: t-notice.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $content = $_POST['content'] ?? '';
    $semester = $_POST['semester'] ?? null;
    $section = $_POST['section'] ?? null;
    $priority = $_POST['priority'] ?? 'normal';
    $noticeId = $_POST['notice_id'] ?? 0;
    
    // Handle file upload
    $pdfPath = null;
    if (isset($_FILES['pdf']) && $_FILES['pdf']['size'] > 0) {
        $uploadDir = '../uploads/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $pdfPath = uniqid() . '_' . basename($_FILES['pdf']['name']);
        move_uploaded_file($_FILES['pdf']['tmp_name'], $uploadDir . $pdfPath);
    }
    
    // Update existing notice
    if ($noticeId) {
        // Get current PDF path
        $stmt = $pdo->prepare("SELECT pdf_path FROM notices WHERE notice_id = ? AND published_by = ?");
        $stmt->execute([$noticeId, $user['user_id']]);
        $currentNotice = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Handle PDF deletion if requested
        if (isset($_POST['delete_pdf']) && $_POST['delete_pdf'] === '1') {
            if ($currentNotice['pdf_path'] && file_exists($uploadDir . $currentNotice['pdf_path'])) {
                unlink($uploadDir . $currentNotice['pdf_path']);
            }
            $pdfPath = null;
        } elseif (!$pdfPath) {
            // Keep existing PDF if not uploading new one and not deleting
            $pdfPath = $currentNotice['pdf_path'];
        } elseif ($currentNotice['pdf_path'] && file_exists($uploadDir . $currentNotice['pdf_path'])) {
            // Delete old PDF if uploading new one
            unlink($uploadDir . $currentNotice['pdf_path']);
        }
        
        $stmt = $pdo->prepare("UPDATE notices SET title = ?, content = ?, pdf_path = ?, semester = ?, section = ?, priority = ? 
                              WHERE notice_id = ? AND published_by = ?");
        $stmt->execute([$title, $content, $pdfPath, $semester, $section, $priority, $noticeId, $user['user_id']]);
    } 
    // Create new notice
    else {
        $stmt = $pdo->prepare("INSERT INTO notices (title, content, pdf_path, published_by, semester, section, priority) 
                              VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title, $content, $pdfPath, $user['user_id'], $semester, $section, $priority]);
    }
    
    header("Location: t-notice.php");
    exit();
}

// Get notices for this teacher
$stmt = $pdo->prepare("SELECT * FROM notices WHERE published_by = ? ORDER BY created_at DESC");
$stmt->execute([$user['user_id']]);
$notices = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get notice for editing
$editNotice = null;
if ($action === 'edit' && $noticeId) {
    $stmt = $pdo->prepare("SELECT * FROM notices WHERE notice_id = ? AND published_by = ?");
    $stmt->execute([$noticeId, $user['user_id']]);
    $editNotice = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$editNotice) {
        header("Location: t-notice.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notice Management | PU</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link href="../assets/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/t-notice.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar section -->
            <aside class="col-md-2">
                <div class="toggle d-flex justify-content-between align-items-center mt-3">
                    <div class="logo d-flex align-items-center gap-2">
                        <img src="../assets/image/Logo_of_Premier_University_(PU).png" class="img-fluid" width="64" height="64">
                        <h2 class="m-0">PU<span class="danger">C</span></h2>
                    </div>
                    <div class="close" id="close-btn">
                        <span class="material-icons-sharp">close</span>
                    </div>
                </div>

                <div class="sidebar bg-white shadow rounded-3 p-3 mt-4 h-88vh position-relative">
                    <a href="teacher_dashboard.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">dashboard</span>
                        <h3 class="m-0 ms-2">Home</h3>
                    </a>
                    <a href="t-contest.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">insights</span>
                        <h3 class="m-0 ms-2">Contest</h3>
                    </a>
                    <a href="t-attendance.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">calendar_today</span>
                        <h3>Attendance</h3>
                    </a>
                    <a href="t-result.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">grading</span>
                        <h3 class="m-0 ms-2">Results</h3>
                    </a>
                    <a href="t-notice.php" class="active d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">mail_outline</span>
                        <h3>Notice</h3>
                    </a>
                    <a href="t-profile.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">settings</span>
                        <h3 class="m-0 ms-2">Profile</h3>
                    </a>
                    <a href="../logout.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded position-absolute bottom-0 start-0 w-100">
                        <span class="material-icons-sharp">logout</span>
                        <h3 class="m-0 ms-2">Logout</h3>
                    </a>
                </div>
            </aside>
            <!-- Sidebar end -->

            <!-- Main content -->
            <main class="col-md-10">
                <h1 class="mt-3 mb-4">Notice Management</h1>
                
                <!-- Notice Form (for both create and edit) -->
                <div class="notice-form">
                    <h3>
                        <span class="material-icons-sharp"><?= $editNotice ? 'edit' : 'add_circle' ?></span>
                        <?= $editNotice ? 'Edit Notice' : 'Create New Notice' ?>
                    </h3>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="notice_id" value="<?= $editNotice ? $editNotice['notice_id'] : '' ?>">
                        
                        <div class="form-group">
                            <label for="noticeTitle">Title</label>
                            <input type="text" class="form-control" id="noticeTitle" name="title" 
                                   value="<?= htmlspecialchars($editNotice['title'] ?? '') ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="noticeContent">Content</label>
                            <textarea class="form-control" id="noticeContent" name="content" rows="5" required><?= 
                                htmlspecialchars($editNotice['content'] ?? '') ?></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="noticePdf">Attach PDF (Optional)</label>
                            <input type="file" class="form-control" id="noticePdf" name="pdf" accept=".pdf">
                            <small class="text-muted">Maximum file size: 5MB</small>
                            
                            <?php if ($editNotice && $editNotice['pdf_path']): ?>
                            <div class="mt-2">
                                <p>Current attachment: 
                                    <a href="../uploads/<?= htmlspecialchars($editNotice['pdf_path']) ?>" target="_blank">
                                        <?= htmlspecialchars(basename($editNotice['pdf_path'])) ?>
                                    </a>
                                </p>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="deletePdf" name="delete_pdf" value="1">
                                    <label class="form-check-label" for="deletePdf">
                                        Delete current PDF
                                    </label>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="filter-controls">
                            <div class="form-group filter-control">
                                <label for="noticeSemester">Semester</label>
                                <select class="form-control" id="noticeSemester" name="semester">
                                    <option value="">All Semesters</option>
                                    <?php 
                                    $semesters = ['1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th'];
                                    foreach ($semesters as $sem): ?>
                                        <option value="<?= $sem ?>" <?= 
                                            ($editNotice['semester'] ?? '') === $sem ? 'selected' : '' ?>>
                                            <?= $sem ?> Semester
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group filter-control">
                                <label for="noticeSection">Section</label>
                                <select class="form-control" id="noticeSection" name="section">
                                    <option value="">All Sections</option>
                                    <?php 
                                    $sections = ['A', 'B', 'C'];
                                    foreach ($sections as $sec): ?>
                                        <option value="<?= $sec ?>" <?= 
                                            ($editNotice['section'] ?? '') === $sec ? 'selected' : '' ?>>
                                            Section <?= $sec ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group filter-control">
                                <label for="noticePriority">Priority</label>
                                <select class="form-control" id="noticePriority" name="priority">
                                    <option value="normal" <?= ($editNotice['priority'] ?? 'normal') === 'normal' ? 'selected' : '' ?>>Normal</option>
                                    <option value="important" <?= ($editNotice['priority'] ?? '') === 'important' ? 'selected' : '' ?>>Important</option>
                                    <option value="urgent" <?= ($editNotice['priority'] ?? '') === 'urgent' ? 'selected' : '' ?>>Urgent</option>
                                </select>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary"><?= $editNotice ? 'Update' : 'Publish' ?> Notice</button>
                        <?php if ($editNotice): ?>
                            <a href="t-notice.php" class="btn btn-secondary">Cancel</a>
                        <?php endif; ?>
                    </form>
                </div>
                
                <!-- Notice List -->
                <div class="notice-container mt-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h3><span class="material-icons-sharp">mail_outline</span> My Notices</h3>
                        <div class="filter-controls">
                            <div class="form-group filter-control">
                                <select class="form-control" id="filterSemester">
                                    <option value="all">All Semesters</option>
                                    <?php foreach ($semesters as $sem): ?>
                                        <option value="<?= $sem ?>"><?= $sem ?> Semester</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group filter-control">
                                <select class="form-control" id="filterPriority">
                                    <option value="all">All Priorities</option>
                                    <option value="normal">Normal</option>
                                    <option value="important">Important</option>
                                    <option value="urgent">Urgent</option>
                                </select>
                            </div>
                            
                            <div class="form-group filter-control">
                                <input type="text" class="form-control" id="searchNotice" placeholder="Search notices...">
                            </div>
                        </div>
                    </div>
                    
                    <div id="noticeList">
                        <?php if (empty($notices)): ?>
                            <div class="alert alert-info">No notices found. Create your first notice using the form above.</div>
                        <?php else: ?>
                            <?php foreach($notices as $notice): ?>
                            <div class="notice-card" data-semester="<?= htmlspecialchars($notice['semester'] ?? '') ?>" 
                                 data-priority="<?= htmlspecialchars($notice['priority'] ?? 'normal') ?>">
                                <div class="notice-actions">
                                    <a href="t-notice.php?action=edit&id=<?= $notice['notice_id'] ?>" class="btn btn-sm btn-primary">
                                        <span class="material-icons-sharp" style="font-size: 16px;">edit</span>
                                    </a>
                                    <a href="t-notice.php?action=delete&id=<?= $notice['notice_id'] ?>" class="btn btn-sm btn-danger" 
                                       onclick="return confirm('Are you sure you want to delete this notice?')">
                                        <span class="material-icons-sharp" style="font-size: 16px;">delete</span>
                                    </a>
                                </div>
                                <h4><?= htmlspecialchars($notice['title']) ?></h4>
                                <div class="notice-date">
                                    Published: <?= date('j F Y', strtotime($notice['created_at'])) ?> | 
                                    <?php if($notice['semester']): ?>Semester: <?= htmlspecialchars($notice['semester']) ?> | <?php endif; ?>
                                    <?php if($notice['section']): ?>Section: <?= htmlspecialchars($notice['section']) ?> | <?php endif; ?>
                                    Priority: <?= ucfirst(htmlspecialchars($notice['priority'])) ?>
                                </div>
                                <p><?= nl2br(htmlspecialchars($notice['content'])) ?></p>
                                <?php if($notice['pdf_path']): ?>
                                <div class="pdf-attachment">
                                    <a href="../uploads/<?= htmlspecialchars($notice['pdf_path']) ?>" class="view-pdf" target="_blank">
                                        <span class="material-icons-sharp">picture_as_pdf</span>
                                        <?= htmlspecialchars(basename($notice['pdf_path'])) ?>
                                    </a>
                                    <a href="t-notice.php?action=delete_pdf&id=<?= $notice['notice_id'] ?>" class="delete-pdf" 
                                       onclick="return confirm('Are you sure you want to delete this PDF?')">Delete</a>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
            <!-- Main content end -->

            <div class="right-section col-md-2 mt-4">
                <div class="nav d-flex justify-content-end gap-4">
                    <button id="menu-btn" class="btn p-0">
                        <span class="material-icons-sharp">menu</span>
                    </button>
                </div>
                <!-- End of Nav -->
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="../assets/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/t-notice.js"></script>
</body>
</html>
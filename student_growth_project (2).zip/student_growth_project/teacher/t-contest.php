<?php
require_once '../includes/auth.php';

// Check if user is logged in and is a teacher
checkAuth();
$user = getCurrentUser($pdo);
if ($user['user_type'] !== 'teacher') {
    header("Location: ../../login.php");
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_contest'])) {
        // Create new contest
        $title = $_POST['title'];
        $description = $_POST['description'];
        $start_time = $_POST['start_time'];
        $end_time = $_POST['end_time'];
        $participants = implode(',', $_POST['participants'] ?? ['All Students']);
        
        $stmt = $pdo->prepare("INSERT INTO contests (title, description, start_time, end_time, participants, created_by) 
                              VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title, $description, $start_time, $end_time, $participants, $user['user_id']]);
        
        $contest_id = $pdo->lastInsertId();
        header("Location: edit_contest.php?id=$contest_id");
        exit();
    }
    
    if (isset($_POST['grade_submission'])) {
        // Grade a submission
        $submission_id = $_POST['submission_id'];
        $score = $_POST['score'];
        $feedback = $_POST['feedback'];
        $status = $_POST['status'];
        $allow_resubmit = isset($_POST['allow_resubmit']) ? 1 : 0;
        
        $stmt = $pdo->prepare("UPDATE contest_submissions
                              SET score = ?, feedback = ?, status = ?, allow_resubmit = ?, graded_at = NOW(), graded_by = ?
                              WHERE id = ?");
        $stmt->execute([$score, $feedback, $status, $allow_resubmit, $user['user_id'], $submission_id]);
        
        $_SESSION['success'] = "Submission graded successfully!";
        header("Location: t-contest.php?tab=submissions");
        exit();
    }
    
    if (isset($_POST['end_contest'])) {
        // End a contest
        $contest_id = $_POST['contest_id'];
        $stmt = $pdo->prepare("UPDATE contests SET end_time = NOW() WHERE id = ? AND created_by = ?");
        $stmt->execute([$contest_id, $user['user_id']]);
        
        $_SESSION['success'] = "Contest ended successfully!";
        header("Location: t-contest.php");
        exit();
    }
}

// Get active tab from query parameter
$active_tab = $_GET['tab'] ?? 'my-contests';

// Get teacher's contests
$stmt = $pdo->prepare("SELECT c.*, 
                      (SELECT COUNT(*) FROM problems WHERE contest_id = c.contest_id) AS problem_count,
                      (SELECT COUNT(DISTINCT teacher_id) FROM contest_submissions WHERE contest_id = c.contest_id) AS participant_count
                      FROM contests c 
                      WHERE c.created_by = ?
                      ORDER BY c.start_time DESC");
$stmt->execute([$user['user_id']]);
$contests = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get submissions for grading
$grading_submissions = [];
$submissions = [];

if ($active_tab === 'submissions' || $active_tab === 'grading') {
    $contest_filter = $_GET['contest_id'] ?? null;
    $problem_filter = $_GET['problem_id'] ?? null;
    $status_filter = $_GET['status'] ?? null;
    
    $query = "SELECT s.*, u.first_name, u.last_name, p.title AS problem_title, c.title AS contest_title 
              FROM contest_submissions s
              JOIN users u ON s.student_id = u.id
              JOIN problems p ON s.problem_id = p.problem_id
              JOIN contests c ON s.contest_id = c.contest_id
              WHERE c.created_by = ?";
    
    $params = [$user['user_id']];
    
    if ($contest_filter) {
        $query .= " AND s.contest_id = ?";
        $params[] = $contest_filter;
    }
    
    if ($problem_filter) {
        $query .= " AND s.problem_id = ?";
        $params[] = $problem_filter;
    }
    
    if ($status_filter) {
        $query .= " AND s.status = ?";
        $params[] = $status_filter;
    }
    
    $query .= " ORDER BY submission_time DESC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $submissions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // For grading tab, we only show ungraded submissions
    if ($active_tab === 'grading') {
        $stmt = $pdo->prepare("SELECT s.*, u.last_name, p.title AS problem_title, c.title AS contest_title 
                              FROM contest_submissions s
                              JOIN users u ON s.student_id = u.user_id
                              JOIN problems p ON s.problem_id = p.problem_id
                              JOIN contests c ON s.contest_id = c.contest_id
                              WHERE c.created_by = ? AND s.status = 'pending'
                              ORDER BY s.submission_time DESC");
        $stmt->execute([$user['user_id']]);
        $grading_submissions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// // Get problems for filters
// $problems = [];
// if ($contest_filter) {
//     $stmt = $pdo->prepare("SELECT id, title FROM problems WHERE contest_id = ?");
//     $stmt->execute([$contest_filter]);
//     $problems = $stmt->fetchAll(PDO::FETCH_ASSOC);
// }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link href="../assets/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/t-contest.css">
    <title>Teacher Contest | PU</title>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar Section -->
            <aside class="col-md-2">
                <div class="toggle d-flex justify-content-between align-items-center mt-3">
                    <div class="logo d-flex align-items-center gap-2">
                        <img src="../assets/image/Logo_of_Premier_University_(PU).png" class="img-fluid" width="64" height="64">
                        <h2 class="m-0">PU<span class="danger">C</span></h2>
                    </div>
                    <div class="close" id="close-btn">
                        <span class="material-icons-sharp">close</span>
                    </div>
                </div>

                <div class="sidebar bg-white shadow rounded-3 p-3 mt-4 h-88vh position-relative">
                    <a href="teacher_dashboard.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">dashboard</span>
                        <h3 class="m-0 ms-2">Home</h3>
                    </a>
                    <a href="t-contest.php" class="active d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">insights</span>
                        <h3 class="m-0 ms-2">Contest</h3>
                    </a>
                    <a href="t-attendance.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">calendar_today</span>
                        <h3>Attendance</h3>
                    </a>
                    <a href="t-result.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">grading</span>
                        <h3 class="m-0 ms-2">Results</h3>
                    </a>
                    <a href="t-notice.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">mail_outline</span>
                        <h3>Notice</h3>
                    </a>
                    <a href="t-profile.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">settings</span>
                        <h3 class="m-0 ms-2">Profile</h3>
                    </a>
                    <a href="../../logout.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded position-absolute bottom-0 start-0 w-100">
                        <span class="material-icons-sharp">logout</span>
                        <h3 class="m-0 ms-2">Logout</h3>
                    </a>
                </div>
            </aside>
            <!-- End of Sidebar Section -->

            <!-- Main Content -->
            <main class="col-md-10">
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?= $_SESSION['success'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['success']); ?>
                <?php endif; ?>
                
                <div class="contest-header d-flex justify-content-between align-items-center border-bottom border-2 border-secondary pb-3 mb-4">
                    <h1 class="fw-bold fs-3">Contest Management</h1>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createContestModal">
                        <span class="material-icons-sharp me-1">add</span> Create Contest
                    </button>
                </div>

                <!-- Contest Tabs -->
                <ul class="nav nav-tabs mb-4" id="contestTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link <?= $active_tab === 'my-contests' ? 'active' : '' ?>" 
                           href="t-contest.php?tab=my-contests">My Contests</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link <?= $active_tab === 'submissions' ? 'active' : '' ?>" 
                           href="t-contest.php?tab=submissions">Submissions</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link <?= $active_tab === 'grading' ? 'active' : '' ?>" 
                           href="t-contest.php?tab=grading">Grading</a>
                    </li>
                </ul>

                <!-- Tab Contents -->
                <div class="tab-content" id="contestTabContent">
                    <!-- My Contests Tab -->
                    <div class="tab-pane fade <?= $active_tab === 'my-contests' ? 'show active' : '' ?>" id="my-contests" role="tabpanel">
                        <div class="row">
                            <?php foreach($contests as $contest): 
                                $current_time = time();
                                $start_time = strtotime($contest['start_time']);
                                $end_time = strtotime($contest['end_time']);
                                
                                if ($current_time < $start_time) {
                                    $status = 'Upcoming';
                                    $badgeClass = 'bg-warning text-dark';
                                } elseif ($current_time >= $start_time && $current_time <= $end_time) {
                                    $status = 'Active';
                                    $badgeClass = 'bg-success';
                                } else {
                                    $status = 'Completed';
                                    $badgeClass = 'bg-secondary';
                                }
                            ?>
                            <div class="col-md-6 mb-3">
                                <div class="contest-card position-relative">
                                    <span class="badge <?= $badgeClass ?> status-badge"><?= $status ?></span>
                                    <h3><?= htmlspecialchars($contest['title']) ?></h3>
                                    <p class="text-muted">For: <?= htmlspecialchars($contest['participants'] ?? 'All Students') ?></p>
                                    <div class="d-flex justify-content-between mb-2">
                                        <small class="text-muted">Start: <?= date('F j, Y - g:i A', $start_time) ?></small>
                                        <small class="text-muted">End: <?= date('F j, Y - g:i A', $end_time) ?></small>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <span class="badge bg-primary"><?= $contest['problem_count'] ?> Problems</span>
                                            <span class="badge bg-info ms-2"><?= $contest['participant_count'] ?> Participants</span>
                                        </div>
                                        <div class="teacher-actions">
                                            <a href="t-contest.php?id=<?= $contest['contest_id'] ?>" class="btn btn-sm btn-outline-primary">View</a>
                                            <a href="t-contest.php?id=<?= $contest['contest_id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                                            <?php if($status === 'Active'): ?>
                                            <form action="t-contest.php" method="POST" class="d-inline">
                                                <input type="hidden" name="contest_id" value="<?= $contest['id'] ?>">
                                                <button type="submit" name="end_contest" class="btn btn-sm btn-outline-danger">End</button>
                                            </form>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            
                            <?php if (empty($contests)): ?>
                            <div class="col-12">
                                <div class="alert alert-info">
                                    You haven't created any contests yet. Click the "Create Contest" button to get started.
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Submissions Tab -->
                    <div class="tab-pane fade <?= $active_tab === 'submissions' ? 'show active' : '' ?>" id="submissions" role="tabpanel">
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <form method="GET" action="t-contest.php" class="filter-form">
                                    <input type="hidden" name="tab" value="submissions">
                                    <select class="form-select" name="contest_id" onchange="this.form.submit()">
                                        <option value="">All Contests</option>
                                        <?php foreach($contests as $contest): ?>
                                        <option value="<?= $contest['contest_id'] ?>" <?= isset($contest_filter) && $contest_filter == $contest['id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($contest['title']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </form>
                            </div>
                            <div class="col-md-4">
                                <form method="GET" action="t-contest.php" class="filter-form">
                                    <input type="hidden" name="tab" value="submissions">
                                    <?php if (isset($contest_filter)): ?>
                                    <input type="hidden" name="contest_id" value="<?= $contest_filter ?>">
                                    <?php endif; ?>
                                    <select class="form-select" name="problem_id" onchange="this.form.submit()">
                                        <option value="">All Problems</option>
                                        <?php foreach($problems as $problem): ?>
                                        <option value="<?= $problem['id'] ?>" <?= isset($problem_filter) && $problem_filter == $problem['id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($problem['title']) ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </form>
                            </div>
                            <div class="col-md-4">
                                <form method="GET" action="t-contest.php" class="filter-form">
                                    <input type="hidden" name="tab" value="submissions">
                                    <?php if (isset($contest_filter)): ?>
                                    <input type="hidden" name="contest_id" value="<?= $contest_filter ?>">
                                    <?php endif; ?>
                                    <?php if (isset($problem_filter)): ?>
                                    <input type="hidden" name="problem_id" value="<?= $problem_filter ?>">
                                    <?php endif; ?>
                                    <select class="form-select" name="status" onchange="this.form.submit()">
                                        <option value="">All Statuses</option>
                                        <option value="pending" <?= isset($status_filter) && $status_filter === 'pending' ? 'selected' : '' ?>>Pending</option>
                                        <option value="accepted" <?= isset($status_filter) && $status_filter === 'accepted' ? 'selected' : '' ?>>Accepted</option>
                                        <option value="rejected" <?= isset($status_filter) && $status_filter === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                                    </select>
                                </form>
                            </div>
                        </div>
                        
                        <div class="submission-list">
                            <?php if (empty($submissions)): ?>
                            <div class="alert alert-info">
                                <?= (isset($contest_filter) || isset($problem_filter) || isset($status_filter)) 
                                    ? 'No submissions match your filters.' 
                                    : 'No submissions found for your contests.' ?>
                            </div>
                            <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Contest</th>
                                            <th>Problem</th>
                                            <th>Student</th>
                                            <th>Submitted At</th>
                                            <th>Status</th>
                                            <th>Score</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($submissions as $submission): ?>
                                        <tr>
                                            <td><?= $submission['id'] ?></td>
                                            <td><?= htmlspecialchars($submission['contest_title']) ?></td>
                                            <td><?= htmlspecialchars($submission['problem_title']) ?></td>
                                            <td><?= htmlspecialchars($submission['username']) ?></td>
                                            <td><?= date('M j, Y g:i A', strtotime($submission['submitted_at'])) ?></td>
                                            <td>
                                                <span class="badge 
                                                    <?= $submission['status'] === 'accepted' ? 'bg-success' : 
                                                       ($submission['status'] === 'rejected' ? 'bg-danger' : 'bg-warning text-dark') ?>">
                                                    <?= ucfirst($submission['status']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?= $submission['score'] !== null ? $submission['score'] : '--' ?>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-primary view-submission" 
                                                        data-bs-toggle="modal" data-bs-target="#viewSubmissionModal"
                                                        data-submission-id="<?= $submission['id'] ?>">
                                                    View
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Grading Tab -->
                    <div class="tab-pane fade <?= $active_tab === 'grading' ? 'show active' : '' ?>" id="grading" role="tabpanel">
                        <?php if (empty($grading_submissions)): ?>
                        <div class="alert alert-success">
                            No submissions need grading at this time.
                        </div>
                        <?php else: ?>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="card mb-4">
                                    <div class="card-header bg-primary text-white">
                                        <h5 class="m-0">Submission Details</h5>
                                    </div>
                                    <div class="card-body">
                                        <?php 
                                        // Get first submission for grading (in a real app, you'd select one to grade)
                                        $submission = $grading_submissions[0]; 
                                        $test_cases = json_decode($submission['test_case_results'], true) ?? [];
                                        ?>
                                        <h5>Problem: <?= htmlspecialchars($submission['problem_title']) ?></h5>
                                        <p class="text-muted">Submitted by: <?= htmlspecialchars($submission['username']) ?></p>
                                        <p class="text-muted">Contest: <?= htmlspecialchars($submission['contest_title']) ?></p>
                                        <p class="text-muted">Submitted at: <?= date('F j, Y - g:i A', strtotime($submission['submitted_at'])) ?></p>
                                        
                                        <h6 class="mt-3">Submitted Code:</h6>
                                        <div class="code-viewer">
                                            <pre><?= htmlspecialchars($submission['code']) ?></pre>
                                        </div>
                                        
                                        <h6 class="mt-3">Test Case Results:</h6>
                                        <?php foreach($test_cases as $index => $test_case): ?>
                                        <div class="test-case-result <?= $test_case['passed'] ? 'test-passed' : 'test-failed' ?>">
                                            <strong>Test Case <?= $index + 1 ?>:</strong> 
                                            <?= $test_case['passed'] ? 'Passed' : 'Failed' ?>
                                            (Input: <?= htmlspecialchars($test_case['input']) ?>, 
                                            Expected: <?= htmlspecialchars($test_case['expected_output']) ?>, 
                                            Output: <?= htmlspecialchars($test_case['actual_output']) ?>)
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-header bg-success text-white">
                                        <h5 class="m-0">Grading Panel</h5>
                                    </div>
                                    <div class="card-body grading-form">
                                        <form action="t-contest.php" method="POST">
                                            <input type="hidden" name="submission_id" value="<?= $submission['id'] ?>">
                                            <div class="mb-3">
                                                <label for="score" class="form-label">Score (Max: 10)</label>
                                                <input type="number" class="form-control" id="score" name="score" min="0" max="10" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="feedback" class="form-label">Feedback/Comments</label>
                                                <textarea class="form-control" id="feedback" name="feedback" rows="4" required></textarea>
                                            </div>
                                            <div class="mb-3 form-check">
                                                <input type="checkbox" class="form-check-input" id="allow_resubmit" name="allow_resubmit">
                                                <label class="form-check-label" for="allow_resubmit">Allow student to resubmit</label>
                                            </div>
                                            <div class="d-grid gap-2">
                                                <button type="submit" name="grade_submission" value="accepted" class="btn btn-success">Accept Submission</button>
                                                <button type="submit" name="grade_submission" value="rejected" class="btn btn-danger">Reject Submission</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>

            <!-- Right Section (Empty now) -->
            <div class="right-section col-md-2 mt-4">
                <!-- This section is left empty as requested -->
            </div>
        </div>
    </div>

    <!-- Create Contest Modal -->
    <div class="modal fade" id="createContestModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create New Contest</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="t-contest.php" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="contest-name" class="form-label">Contest Name</label>
                            <input type="text" class="form-control" id="contest-name" name="title" required>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="start-time" class="form-label">Start Time</label>
                                <input type="datetime-local" class="form-control" id="start-time" name="start_time" required>
                            </div>
                            <div class="col-md-6">
                                <label for="end-time" class="form-label">End Time</label>
                                <input type="datetime-local" class="form-control" id="end-time" name="end_time" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="contest-description" class="form-label">Description</label>
                            <textarea class="form-control" id="contest-description" name="description" rows="3"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="participant-list" class="form-label">Participants</label>
                            <select class="form-select" id="participant-list" name="participants[]" multiple>
                                <option value="CSE 3rd Year">CSE 3rd Year</option>
                                <option value="CSE 4th Year">CSE 4th Year</option>
                                <option value="All Students">All Students</option>
                            </select>
                            <small class="text-muted">Hold Ctrl/Cmd to select multiple options</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="create_contest" class="btn btn-primary">Create Contest</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Submission Modal -->
    <div class="modal fade" id="viewSubmissionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Submission Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="submissionModalContent">
                    <!-- Content will be loaded via AJAX -->
                    <div class="text-center my-5">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/t-contest.js"></script>
</body>
</html>
<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';
checkAuth();

$user = getCurrentUser($GLOBALS['pdo']);
if ($user['user_type'] !== 'teacher') {
    header("Location: " . ($user['user_type'] === 'student' ? "../index.php" : "../login.php"));
    exit();
}

// Get teacher details
$stmt = $GLOBALS['pdo']->prepare("SELECT t.*, u.first_name, u.last_name, u.email, u.profile_image, u.department 
                                 FROM teachers t 
                                 JOIN users u ON t.user_id = u.user_id 
                                 WHERE t.user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

// Get courses assigned to this teacher
$stmt = $GLOBALS['pdo']->prepare("SELECT c.course_id, c.course_name, c.credit, c.semester 
                                 FROM courses c 
                                 WHERE c.teacher_id = ?");
$stmt->execute([$teacher['user_id']]);
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get unique semesters from the teacher's courses
$semesters = [];
foreach ($courses as $course) {
    if (!in_array($course['semester'], $semesters)) {
        $semesters[] = $course['semester'];
    }
}

// Get student count and students by semester
$student_count = 0;
$students_by_semester = [];

foreach ($semesters as $semester) {
    // Get students in this semester who are taking the teacher's courses
    $stmt = $GLOBALS['pdo']->prepare("SELECT DISTINCT s.roll_number, u.first_name, u.last_name, u.email, s.semester 
                                     FROM students s 
                                     JOIN users u ON s.user_id = u.user_id 
                                     JOIN enrollments sc ON s.roll_number = sc.student_id
                                     JOIN courses c ON sc.course_code = c.course_id
                                     WHERE c.teacher_id = ? AND c.semester = ?
                                     ORDER BY s.roll_number");
    $stmt->execute([$teacher['user_id'], $semester]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $students_by_semester[$semester] = $students;
    $student_count += count($students);
}

// Get current semester students (first semester if available)
$current_students = !empty($semesters) ? $students_by_semester[$semesters[0]] : [];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link href="../assets/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/t-style.css">
    <title>Teacher Dashboard | PU</title>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar section -->
            <aside class="col-md-2">
                <div class="toggle d-flex justify-content-between align-items-center mt-3">
                    <div class="logo d-flex align-items-center gap-2">
                        <img src="../assets/image/Logo_of_Premier_University_(PU).png" class="img-fluid" width="64" height="64">
                        <h2 class="m-0">PU<span class="danger">C</span></h2>
                    </div>
                    <div class="close" id="close-btn">
                        <span class="material-icons-sharp">close</span>
                    </div>
                </div>

                <div class="sidebar bg-white shadow rounded-3 p-3 mt-4 h-88vh position-relative">
                    <a href="teacher_dashboard.php" class="active d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">dashboard</span>
                        <h3 class="m-0 ms-2">Home</h3>
                    </a>
                    <a href="t-contest.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">insights</span>
                        <h3 class="m-0 ms-2">Contest</h3>
                    </a>
                    <a href="t-attendance.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">calendar_today</span>
                        <h3>Attendance</h3>
                    </a>
                    <a href="t-result.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">grading</span>
                        <h3 class="m-0 ms-2">Results</h3>
                    </a>
                    <a href="t-notice.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">mail_outline</span>
                        <h3>Notice</h3>
                    </a>
                    <a href="t-profile.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded">
                        <span class="material-icons-sharp">settings</span>
                        <h3 class="m-0 ms-2">Profile</h3>
                    </a>
                    <a href="../logout.php" class="d-flex align-items-center text-decoration-none text-dark py-3 px-3 rounded position-absolute bottom-0 start-0 w-100">
                        <span class="material-icons-sharp">logout</span>
                        <h3 class="m-0 ms-2">Logout</h3>
                    </a>
                </div>
            </aside>
            <!-- Sidebar end -->

            <!-- Main content -->
            <main class="col-md-10">
                <!-- Teacher profile section -->
                <div class="teacher-profile">
                    <img src="../uploads/profile_images/<?php echo $teacher['profile_image'] ?: 'default_profile.jpg'; ?>" alt="Teacher's photo">
                    <div class="teacher-info">
                        <h2><?php echo htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name']); ?></h2>
                        <p><strong>Department:</strong> <?php echo htmlspecialchars($teacher['department']); ?></p>
                        <p><strong>Position:</strong> <?php echo htmlspecialchars($teacher['position']); ?></p>
                        <p><strong>Teacher ID:</strong> <?php echo htmlspecialchars($teacher['teacher_id']); ?></p>
                    </div>
                </div>
                
                <!-- Stats section -->
                <div class="stats-container">
                    <div class="stat-card">
                        <div class="stat-value"><?php echo $student_count; ?></div>
                        <div class="stat-title">Total Students</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?php echo count($courses); ?></div>
                        <div class="stat-title">Courses</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?php echo count($semesters); ?></div>
                        <div class="stat-title">Semesters</div>
                    </div>
                </div>
                
                <!-- Assigned courses -->
                <div class="semester-section-container">
                    <h3><span class="material-icons-sharp">assignment</span> My Assigned Courses</h3>
                    
                    <?php if (!empty($courses)): ?>
                        <div class="row">
                            <?php foreach ($courses as $course): ?>
                            <div class="col-md-4 mb-3">
                                <div class="section-card h-100">
                                    <h4><?php echo htmlspecialchars($course['course_name']); ?></h4>
                                    <p><strong>Credit:</strong> <?php echo htmlspecialchars($course['credit']); ?></p>
                                    <p><strong>Course ID:</strong> <?php echo htmlspecialchars($course['course_id']); ?></p>
                                    <p><strong>Semester:</strong> <?php echo htmlspecialchars($course['semester']); ?>th</p>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">No courses assigned yet.</div>
                    <?php endif; ?>
                </div>
                
                <!-- Student list -->
                <div class="semester-section-container">
                    <h3><span class="material-icons-sharp">groups</span> My Students List</h3>
                    
                    <?php if (!empty($semesters)): ?>
                        <div class="section-tabs mb-3">
                            <?php foreach ($semesters as $index => $semester): ?>
                            <div class="section-tab <?php echo $index === 0 ? 'active' : ''; ?>" 
                                 data-semester="<?php echo $semester; ?>">
                                <?php echo $semester; ?>th Semester
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="table-responsive">
                            <table class="students-table table table-striped table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>Student ID</th>
                                        <th>Name</th>
                                        <th>Semester</th>
                                        <th>Email</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($current_students as $student): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($student['roll_number']); ?></td>
                                        <td><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                                        <td><?php echo htmlspecialchars($student['semester']); ?>th</td>
                                        <td><?php echo htmlspecialchars($student['email']); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">No students found in your assigned courses.</div>
                    <?php endif; ?>
                </div>
            </main>
            <!-- Main content end -->

            <div class="right-section col-md-2 mt-4">
                <div class="nav d-flex justify-content-end gap-4">
                    <button id="menu-btn" class="btn p-0">
                        <span class="material-icons-sharp">menu</span>
                    </button>
                </div>
                <!-- End of Nav -->
            </div>
        </div>
    </div>

    <script src="../assets/bootstrap/bootstrap.bundle.min.js"></script>
    <script>
        // Semester tab filtering
        document.querySelectorAll('.section-tab').forEach(tab => {
            tab.addEventListener('click', function() {
                const semester = this.getAttribute('data-semester');
                
                // Remove active class from all tabs
                document.querySelectorAll('.section-tab').forEach(t => t.classList.remove('active'));
                // Add active class to clicked tab
                this.classList.add('active');
                
                // Filter students for the selected semester
                const students = <?php echo json_encode($students_by_semester); ?>;
                const semesterStudents = students[semester] || [];
                
                const tbody = document.querySelector('.students-table tbody');
                tbody.innerHTML = '';
                
                semesterStudents.forEach(student => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${student.roll_number}</td>
                        <td>${student.first_name} ${student.last_name}</td>
                        <td>${student.semester}th</td>
                        <td>${student.email}</td>
                    `;
                    tbody.appendChild(row);
                });
            });
        });

        // Sidebar toggle for mobile view
        const sideMenu = document.querySelector('aside');
        const menuBtn = document.getElementById('menu-btn');
        const closeBtn = document.getElementById('close-btn');

        menuBtn.addEventListener('click', () => {
            sideMenu.style.display = 'block';
            sideMenu.style.position = 'fixed';
            sideMenu.style.zIndex = '1000';
        });

        closeBtn.addEventListener('click', () => {
            sideMenu.style.display = 'none';
        });

        // Handle window resize
        window.addEventListener('resize', () => {
            if (window.innerWidth > 992) {
                sideMenu.style.display = 'block';
                sideMenu.style.position = 'relative';
            } else {
                sideMenu.style.display = 'none';
            }
        });

        // Initialize on page load
        if (window.innerWidth > 992) {
            sideMenu.style.display = 'block';
            sideMenu.style.position = 'relative';
        } else {
            sideMenu.style.display = 'none';
        }
    </script>
</body>
</html>
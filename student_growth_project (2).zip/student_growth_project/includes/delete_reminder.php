<?php
// At the top of delete_reminder.php
error_log("Delete request received. Data: " . print_r($data, true));
error_log("Session user ID: " . $_SESSION['user_id']);
require_once 'auth.php';
checkAuth();

header('Content-Type: application/json');

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get the raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate JSON data
if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON data']);
    exit;
}

// Check if reminder_id exists
if (!isset($data['reminder_id']) || empty($data['reminder_id'])) {
    echo json_encode(['success' => false, 'message' => 'Reminder ID is required']);
    exit;
}

try {
    // Verify the reminder belongs to the current user before deleting
    $stmt = $GLOBALS['pdo']->prepare("DELETE FROM reminders WHERE reminder_id = :reminder_id AND user_id = :user_id");
    $stmt->execute([
        ':reminder_id' => $data['reminder_id'],
        ':user_id' => $_SESSION['user_id']
    ]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Reminder deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Reminder not found or not authorized']);
    }
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
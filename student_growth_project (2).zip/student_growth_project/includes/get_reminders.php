<?php
require_once 'auth.php';
checkAuth();

header('Content-Type: application/json');

try {
    $stmt = $pdo->prepare("SELECT * FROM reminders 
                          WHERE user_id = ? AND due_date >= CURDATE()
                          ORDER BY due_date ASC LIMIT 5");
    $stmt->execute([$_SESSION['user_id']]);
    $reminders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'reminders' => $reminders
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?.
<?php
require_once 'auth.php';
checkAuth();

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['title']) || !isset($data['due_date']) || !isset($data['user_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit();
}

try {
    $stmt = $pdo->prepare("INSERT INTO reminders (user_id, title, due_date) VALUES (?, ?, ?)");
    $stmt->execute([$data['user_id'], $data['title'], $data['due_date']]);
    
    $id = $pdo->lastInsertId();
    echo json_encode([
        'success' => true,
        'id' => $id
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
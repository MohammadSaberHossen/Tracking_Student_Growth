<?php
// includes/functions.php

// Add this new function
function calculateCGPA($pdo, $student_id) {
    $stmt = $pdo->prepare("SELECT grade FROM results WHERE student_id = ? AND published = 1");
    $stmt->execute([$student_id]);
    $grades = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $total_grade_points = 0;
    $total_courses = count($grades);
    
    foreach ($grades as $grade) {
        switch ($grade) {
            case 'A+': $total_grade_points += 4.0; break;
            case 'A':  $total_grade_points += 3.75; break;
            case 'A-': $total_grade_points += 3.5; break;
            case 'B+': $total_grade_points += 3.25; break;
            case 'B':  $total_grade_points += 3.0; break;
            case 'B-': $total_grade_points += 2.75; break;
            case 'C+': $total_grade_points += 2.5; break;
            case 'C':  $total_grade_points += 2.25; break;
            case 'D':  $total_grade_points += 2.0; break;
            case 'F':  $total_grade_points += 0.0; break;
        }
    }
    
    return $total_courses > 0 ? $total_grade_points / $total_courses : 0;
}
?>